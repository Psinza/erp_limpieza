# apps/rrhh/views.py
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q, Count, Sum
from django.utils import timezone

from .models import Empleado, Cargo, Departamento, Nomina, DetalleNomina, Vacacion
from .forms  import (
    EmpleadoForm, CargoForm, DepartamentoForm,
    NominaForm, DetalleNominaForm, VacacionForm,
)


# ──────────────────────────────────────────────
# DASHBOARD
# ──────────────────────────────────────────────
@login_required
def dashboard_rrhh(request):
    total_empleados     = Empleado.objects.filter(estado="activo").count()
    total_nomina        = (
        Nomina.objects.filter(estado="pagada")
        .aggregate(Sum("total_neto"))["total_neto__sum"] or 0
    )
    vacaciones_pend     = Vacacion.objects.filter(estado="pendiente").count()
    empleados_recientes = Empleado.objects.order_by("-creado_en")[:5]
    nominas_recientes   = Nomina.objects.order_by("-periodo")[:5]

    return render(request, "rrhh/dashboard_rrhh.html", {
        "total_empleados":    total_empleados,
        "total_nomina":       total_nomina,
        "vacaciones_pend":    vacaciones_pend,
        "empleados_recientes":empleados_recientes,
        "nominas_recientes":  nominas_recientes,
    })


# ──────────────────────────────────────────────
# DEPARTAMENTOS
# ──────────────────────────────────────────────
@login_required
def departamento_list(request):
    qs = Departamento.objects.annotate(num_cargos=Count("cargos"))
    return render(request, "rrhh/departamento_list.html", {"departamentos": qs})


@login_required
def departamento_create(request):
    form = DepartamentoForm(request.POST or None)
    if form.is_valid():
        form.save()
        messages.success(request, "Departamento creado correctamente.")
        return redirect("rrhh:departamento_list")
    return render(request, "rrhh/departamento_form.html", {
        "form": form, "titulo": "Nuevo Departamento"
    })


@login_required
def departamento_edit(request, pk):
    obj  = get_object_or_404(Departamento, pk=pk)
    form = DepartamentoForm(request.POST or None, instance=obj)
    if form.is_valid():
        form.save()
        messages.success(request, "Departamento actualizado.")
        return redirect("rrhh:departamento_list")
    return render(request, "rrhh/departamento_form.html", {
        "form": form, "titulo": "Editar Departamento"
    })


# ──────────────────────────────────────────────
# CARGOS
# ──────────────────────────────────────────────
@login_required
def cargo_list(request):
    cargos = Cargo.objects.select_related("departamento").filter(activo=True)
    return render(request, "rrhh/cargo_list.html", {"cargos": cargos})


@login_required
def cargo_create(request):
    form = CargoForm(request.POST or None)
    if form.is_valid():
        form.save()
        messages.success(request, "Cargo creado correctamente.")
        return redirect("rrhh:cargo_list")
    return render(request, "rrhh/cargo_form.html", {"form": form, "titulo": "Nuevo Cargo"})


@login_required
def cargo_edit(request, pk):
    obj  = get_object_or_404(Cargo, pk=pk)
    form = CargoForm(request.POST or None, instance=obj)
    if form.is_valid():
        form.save()
        messages.success(request, "Cargo actualizado.")
        return redirect("rrhh:cargo_list")
    return render(request, "rrhh/cargo_form.html", {"form": form, "titulo": "Editar Cargo"})


# ──────────────────────────────────────────────
# EMPLEADOS
# ──────────────────────────────────────────────
@login_required
def empleado_list(request):
    q   = request.GET.get("q", "")
    dep = request.GET.get("departamento", "")
    est = request.GET.get("estado", "")

    qs = Empleado.objects.select_related("cargo__departamento")

    if q:
        qs = qs.filter(
            Q(nombres__icontains=q)   |
            Q(apellidos__icontains=q) |
            Q(cedula__icontains=q)
        )
    if dep:
        qs = qs.filter(cargo__departamento__id=dep)
    if est:
        qs = qs.filter(estado=est)

    departamentos = Departamento.objects.filter(activo=True)
    return render(request, "rrhh/empleado_list.html", {
        "empleados":    qs,
        "departamentos":departamentos,
        "q": q, "dep": dep, "est": est,
    })


@login_required
def empleado_detail(request, pk):
    emp        = get_object_or_404(Empleado, pk=pk)
    vacaciones = emp.vacaciones.order_by("-fecha_inicio")[:10]
    nominas    = emp.detalles_nomina.select_related("nomina").order_by("-nomina__periodo")[:10]
    return render(request, "rrhh/empleado_detail.html", {
        "emp": emp, "vacaciones": vacaciones, "nominas": nominas,
    })


@login_required
def empleado_create(request):
    form = EmpleadoForm(request.POST or None, request.FILES or None)
    if form.is_valid():
        emp = form.save(commit=False)
        emp.creado_por = request.user
        emp.save()
        messages.success(request, f"Empleado {emp.nombre_completo} creado.")
        return redirect("rrhh:empleado_detail", pk=emp.pk)
    return render(request, "rrhh/empleado_form.html", {"form": form, "titulo": "Nuevo Empleado"})


@login_required
def empleado_edit(request, pk):
    emp  = get_object_or_404(Empleado, pk=pk)
    form = EmpleadoForm(request.POST or None, request.FILES or None, instance=emp)
    if form.is_valid():
        form.save()
        messages.success(request, "Empleado actualizado.")
        return redirect("rrhh:empleado_detail", pk=emp.pk)
    return render(request, "rrhh/empleado_form.html", {
        "form": form, "titulo": "Editar Empleado", "emp": emp,
    })


@login_required
def empleado_delete(request, pk):
    emp = get_object_or_404(Empleado, pk=pk)
    if request.method == "POST":
        emp.estado       = "inactivo"
        emp.fecha_egreso = timezone.now().date()
        emp.save()
        messages.warning(request, f"Empleado {emp.nombre_completo} dado de baja.")
        return redirect("rrhh:empleado_list")
    return render(request, "rrhh/empleado_confirm_delete.html", {"emp": emp})


# ──────────────────────────────────────────────
# VACACIONES
# ──────────────────────────────────────────────
@login_required
def vacacion_list(request):
    qs = Vacacion.objects.select_related("empleado", "aprobado_por").order_by("-creado_en")
    return render(request, "rrhh/vacacion_list.html", {"vacaciones": qs})


@login_required
def vacacion_create(request):
    form = VacacionForm(request.POST or None)
    if form.is_valid():
        form.save()
        messages.success(request, "Solicitud de vacaciones registrada.")
        return redirect("rrhh:vacacion_list")
    return render(request, "rrhh/vacacion_form.html", {"form": form})


@login_required
def vacacion_aprobar(request, pk):
    vac = get_object_or_404(Vacacion, pk=pk)
    if request.method == "POST":
        accion = request.POST.get("accion")
        if accion == "aprobar":
            vac.estado       = "aprobada"
            vac.aprobado_por = request.user
            messages.success(request, "Vacaciones aprobadas.")
        elif accion == "rechazar":
            vac.estado = "rechazada"
            messages.warning(request, "Vacaciones rechazadas.")
        vac.save()
    return redirect("rrhh:vacacion_list")


# ──────────────────────────────────────────────
# NÓMINA
# ──────────────────────────────────────────────
@login_required
def nomina_list(request):
    nominas = Nomina.objects.order_by("-periodo")
    return render(request, "rrhh/nomina_list.html", {"nominas": nominas})


@login_required
def nomina_create(request):
    form = NominaForm(request.POST or None)
    if form.is_valid():
        nom = form.save(commit=False)
        nom.creado_por = request.user
        nom.save()
        messages.success(request, f"Nómina {nom.periodo} creada.")
        return redirect("rrhh:nomina_detail", pk=nom.pk)
    return render(request, "rrhh/nomina_form.html", {"form": form})


@login_required
def nomina_detail(request, pk):
    nom      = get_object_or_404(Nomina, pk=pk)
    detalles = nom.detalles.select_related("empleado").all()
    det_form = DetalleNominaForm()
    return render(request, "rrhh/nomina_detail.html", {
        "nom": nom, "detalles": detalles, "det_form": det_form,
    })


@login_required
def nomina_agregar_empleado(request, pk):
    nom = get_object_or_404(Nomina, pk=pk)
    if nom.estado != "borrador":
        messages.error(request, "Solo se pueden agregar empleados en estado Borrador.")
        return redirect("rrhh:nomina_detail", pk=pk)
    form = DetalleNominaForm(request.POST)
    if form.is_valid():
        det        = form.save(commit=False)
        det.nomina = nom
        det.save()
        nom.calcular_totales()
        messages.success(request, "Empleado agregado a la nómina.")
    else:
        messages.error(request, "Error al agregar empleado.")
    return redirect("rrhh:nomina_detail", pk=pk)


@login_required
def nomina_calcular(request, pk):
    nom = get_object_or_404(Nomina, pk=pk)
    nom.calcular_totales()
    nom.estado = "calculada"
    nom.save()
    messages.success(request, "Nómina calculada correctamente.")
    return redirect("rrhh:nomina_detail", pk=pk)


@login_required
def nomina_aprobar(request, pk):
    nom = get_object_or_404(Nomina, pk=pk)
    if nom.estado == "calculada":
        nom.estado       = "aprobada"
        nom.aprobado_por = request.user
        nom.save()
        messages.success(request, "Nómina aprobada.")
    else:
        messages.error(request, "La nómina debe estar calculada primero.")
    return redirect("rrhh:nomina_detail", pk=pk)


@login_required
def nomina_pagar(request, pk):
    nom = get_object_or_404(Nomina, pk=pk)
    if nom.estado == "aprobada":
        nom.estado = "pagada"
        nom.save()
        messages.success(request, "Nómina marcada como pagada.")
    else:
        messages.error(request, "La nómina debe estar aprobada.")
    return redirect("rrhh:nomina_detail", pk=pk)
