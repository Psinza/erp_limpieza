# apps/rrhh/forms.py
from django import forms
from .models import Empleado, Cargo, Departamento, Nomina, DetalleNomina, Vacacion


class DepartamentoForm(forms.ModelForm):
    class Meta:
        model  = Departamento
        fields = ["nombre", "descripcion", "activo"]
        widgets = {
            "nombre":      forms.TextInput(attrs={"class": "form-control"}),
            "descripcion": forms.Textarea(attrs={"class": "form-control", "rows": 3}),
            "activo":      forms.CheckboxInput(attrs={"class": "form-check-input"}),
        }


class CargoForm(forms.ModelForm):
    class Meta:
        model  = Cargo
        fields = ["nombre", "departamento", "descripcion", "salario_base", "activo"]
        widgets = {
            "nombre":       forms.TextInput(attrs={"class": "form-control"}),
            "departamento": forms.Select(attrs={"class": "form-select"}),
            "descripcion":  forms.Textarea(attrs={"class": "form-control", "rows": 3}),
            "salario_base": forms.NumberInput(attrs={"class": "form-control", "step": "0.01"}),
            "activo":       forms.CheckboxInput(attrs={"class": "form-check-input"}),
        }


class EmpleadoForm(forms.ModelForm):
    class Meta:
        model  = Empleado
        fields = [
            "cedula", "nombres", "apellidos", "sexo", "fecha_nacimiento",
            "telefono", "email", "direccion", "foto",
            "cargo", "tipo_contrato", "fecha_ingreso", "salario", "estado",
        ]
        widgets = {
            "cedula":           forms.TextInput(attrs={"class": "form-control"}),
            "nombres":          forms.TextInput(attrs={"class": "form-control"}),
            "apellidos":        forms.TextInput(attrs={"class": "form-control"}),
            "sexo":             forms.Select(attrs={"class": "form-select"}),
            "fecha_nacimiento": forms.DateInput(attrs={"class": "form-control", "type": "date"}),
            "telefono":         forms.TextInput(attrs={"class": "form-control"}),
            "email":            forms.EmailInput(attrs={"class": "form-control"}),
            "direccion":        forms.Textarea(attrs={"class": "form-control", "rows": 2}),
            "foto":             forms.ClearableFileInput(attrs={"class": "form-control"}),
            "cargo":            forms.Select(attrs={"class": "form-select"}),
            "tipo_contrato":    forms.Select(attrs={"class": "form-select"}),
            "fecha_ingreso":    forms.DateInput(attrs={"class": "form-control", "type": "date"}),
            "salario":          forms.NumberInput(attrs={"class": "form-control", "step": "0.01"}),
            "estado":           forms.Select(attrs={"class": "form-select"}),
        }


class VacacionForm(forms.ModelForm):
    class Meta:
        model  = Vacacion
        fields = ["empleado", "fecha_inicio", "fecha_fin", "dias_solicitados", "motivo"]
        widgets = {
            "empleado":         forms.Select(attrs={"class": "form-select"}),
            "fecha_inicio":     forms.DateInput(attrs={"class": "form-control", "type": "date"}),
            "fecha_fin":        forms.DateInput(attrs={"class": "form-control", "type": "date"}),
            "dias_solicitados": forms.NumberInput(attrs={"class": "form-control"}),
            "motivo":           forms.Textarea(attrs={"class": "form-control", "rows": 3}),
        }


class NominaForm(forms.ModelForm):
    class Meta:
        model  = Nomina
        fields = ["periodo", "descripcion"]
        widgets = {
            "periodo":     forms.TextInput(attrs={"class": "form-control", "placeholder": "2025-01"}),
            "descripcion": forms.TextInput(attrs={"class": "form-control"}),
        }


class DetalleNominaForm(forms.ModelForm):
    class Meta:
        model  = DetalleNomina
        fields = [
            "empleado", "salario_bruto", "horas_extra", "bonificaciones",
            "seguro_social", "impuesto_renta", "otras_deducciones", "observaciones",
        ]
        widgets = {
            "empleado":          forms.Select(attrs={"class": "form-select"}),
            "salario_bruto":     forms.NumberInput(attrs={"class": "form-control", "step": "0.01"}),
            "horas_extra":       forms.NumberInput(attrs={"class": "form-control", "step": "0.01"}),
            "bonificaciones":    forms.NumberInput(attrs={"class": "form-control", "step": "0.01"}),
            "seguro_social":     forms.NumberInput(attrs={"class": "form-control", "step": "0.01"}),
            "impuesto_renta":    forms.NumberInput(attrs={"class": "form-control", "step": "0.01"}),
            "otras_deducciones": forms.NumberInput(attrs={"class": "form-control", "step": "0.01"}),
            "observaciones":     forms.Textarea(attrs={"class": "form-control", "rows": 2}),
        }
