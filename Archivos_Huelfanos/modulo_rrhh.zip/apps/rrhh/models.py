# apps/rrhh/models.py
from django.db import models
from django.contrib.auth import get_user_model
from django.core.validators import MinValueValidator
from decimal import Decimal

User = get_user_model()


class Departamento(models.Model):
    nombre       = models.CharField(max_length=100, unique=True)
    descripcion  = models.TextField(blank=True)
    activo       = models.BooleanField(default=True)
    creado_en    = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name        = "Departamento"
        verbose_name_plural = "Departamentos"
        ordering            = ["nombre"]

    def __str__(self):
        return self.nombre


class Cargo(models.Model):
    nombre        = models.CharField(max_length=100)
    departamento  = models.ForeignKey(
        Departamento, on_delete=models.PROTECT, related_name="cargos"
    )
    descripcion   = models.TextField(blank=True)
    salario_base  = models.DecimalField(
        max_digits=12, decimal_places=2,
        validators=[MinValueValidator(Decimal("0.01"))]
    )
    activo        = models.BooleanField(default=True)
    creado_en     = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name        = "Cargo"
        verbose_name_plural = "Cargos"
        ordering            = ["departamento", "nombre"]
        unique_together     = ["nombre", "departamento"]

    def __str__(self):
        return f"{self.nombre} — {self.departamento}"


class Empleado(models.Model):
    ESTADO_CHOICES = [
        ("activo",      "Activo"),
        ("inactivo",    "Inactivo"),
        ("vacaciones",  "De vacaciones"),
        ("baja",        "Baja médica"),
        ("suspendido",  "Suspendido"),
    ]
    TIPO_CONTRATO_CHOICES = [
        ("indefinido",  "Indefinido"),
        ("temporal",    "Temporal"),
        ("practicas",   "Prácticas"),
        ("obra",        "Por obra"),
    ]
    SEXO_CHOICES = [
        ("M", "Masculino"),
        ("F", "Femenino"),
        ("O", "Otro"),
    ]

    # Datos personales
    cedula           = models.CharField(max_length=20, unique=True, verbose_name="Cédula / DNI")
    nombres          = models.CharField(max_length=100)
    apellidos        = models.CharField(max_length=100)
    sexo             = models.CharField(max_length=1, choices=SEXO_CHOICES, default="M")
    fecha_nacimiento = models.DateField()
    telefono         = models.CharField(max_length=20, blank=True)
    email            = models.EmailField(blank=True)
    direccion        = models.TextField(blank=True)
    foto             = models.ImageField(upload_to="empleados/fotos/", blank=True, null=True)

    # Datos laborales
    cargo            = models.ForeignKey(Cargo, on_delete=models.PROTECT, related_name="empleados")
    tipo_contrato    = models.CharField(max_length=20, choices=TIPO_CONTRATO_CHOICES, default="indefinido")
    fecha_ingreso    = models.DateField()
    fecha_egreso     = models.DateField(blank=True, null=True)
    salario          = models.DecimalField(
        max_digits=12, decimal_places=2,
        validators=[MinValueValidator(Decimal("0.01"))]
    )
    estado           = models.CharField(max_length=15, choices=ESTADO_CHOICES, default="activo")

    # Usuario del sistema (opcional)
    usuario          = models.OneToOneField(
        User, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="empleado"
    )

    # Auditoría
    creado_por       = models.ForeignKey(
        User, on_delete=models.SET_NULL,
        null=True, related_name="empleados_creados"
    )
    creado_en        = models.DateTimeField(auto_now_add=True)
    modificado_en    = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name        = "Empleado"
        verbose_name_plural = "Empleados"
        ordering            = ["apellidos", "nombres"]

    def __str__(self):
        return f"{self.apellidos}, {self.nombres} [{self.cedula}]"

    @property
    def nombre_completo(self):
        return f"{self.nombres} {self.apellidos}"

    @property
    def departamento(self):
        return self.cargo.departamento


class Vacacion(models.Model):
    ESTADO_CHOICES = [
        ("pendiente", "Pendiente"),
        ("aprobada",  "Aprobada"),
        ("rechazada", "Rechazada"),
    ]

    empleado         = models.ForeignKey(Empleado, on_delete=models.CASCADE, related_name="vacaciones")
    fecha_inicio     = models.DateField()
    fecha_fin        = models.DateField()
    dias_solicitados = models.PositiveIntegerField()
    motivo           = models.TextField(blank=True)
    estado           = models.CharField(max_length=10, choices=ESTADO_CHOICES, default="pendiente")
    aprobado_por     = models.ForeignKey(
        User, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="vacaciones_aprobadas"
    )
    creado_en        = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name        = "Vacación"
        verbose_name_plural = "Vacaciones"
        ordering            = ["-fecha_inicio"]

    def __str__(self):
        return f"{self.empleado} | {self.fecha_inicio} → {self.fecha_fin}"


class Nomina(models.Model):
    ESTADO_CHOICES = [
        ("borrador",  "Borrador"),
        ("calculada", "Calculada"),
        ("aprobada",  "Aprobada"),
        ("pagada",    "Pagada"),
    ]

    periodo          = models.CharField(max_length=7, help_text="Formato: YYYY-MM")
    descripcion      = models.CharField(max_length=200, blank=True)
    estado           = models.CharField(max_length=10, choices=ESTADO_CHOICES, default="borrador")
    total_bruto      = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal("0.00"))
    total_deducciones= models.DecimalField(max_digits=14, decimal_places=2, default=Decimal("0.00"))
    total_neto       = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal("0.00"))
    creado_por       = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, related_name="nominas_creadas"
    )
    creado_en        = models.DateTimeField(auto_now_add=True)
    aprobado_por     = models.ForeignKey(
        User, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="nominas_aprobadas"
    )

    class Meta:
        verbose_name        = "Nómina"
        verbose_name_plural = "Nóminas"
        ordering            = ["-periodo"]
        unique_together     = ["periodo"]

    def __str__(self):
        return f"Nómina {self.periodo} — {self.get_estado_display()}"

    def calcular_totales(self):
        detalles = self.detalles.all()
        self.total_bruto         = sum(d.salario_bruto       for d in detalles)
        self.total_deducciones   = sum(d.total_deducciones   for d in detalles)
        self.total_neto          = sum(d.salario_neto        for d in detalles)
        self.save()


class DetalleNomina(models.Model):
    nomina           = models.ForeignKey(Nomina, on_delete=models.CASCADE, related_name="detalles")
    empleado         = models.ForeignKey(Empleado, on_delete=models.PROTECT, related_name="detalles_nomina")

    # Ingresos
    salario_bruto    = models.DecimalField(max_digits=12, decimal_places=2)
    horas_extra      = models.DecimalField(max_digits=8,  decimal_places=2, default=Decimal("0.00"))
    bonificaciones   = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal("0.00"))

    # Deducciones
    seguro_social    = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal("0.00"))
    impuesto_renta   = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal("0.00"))
    otras_deducciones= models.DecimalField(max_digits=12, decimal_places=2, default=Decimal("0.00"))

    # Calculados
    total_deducciones= models.DecimalField(max_digits=12, decimal_places=2, default=Decimal("0.00"))
    salario_neto     = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal("0.00"))

    observaciones    = models.TextField(blank=True)

    class Meta:
        verbose_name        = "Detalle de Nómina"
        verbose_name_plural = "Detalles de Nómina"
        unique_together     = ["nomina", "empleado"]

    def __str__(self):
        return f"{self.nomina} | {self.empleado}"

    def save(self, *args, **kwargs):
        self.total_deducciones = (
            self.seguro_social + self.impuesto_renta + self.otras_deducciones
        )
        self.salario_neto = (
            self.salario_bruto + self.bonificaciones + self.horas_extra
            - self.total_deducciones
        )
        super().save(*args, **kwargs)
