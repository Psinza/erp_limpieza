# apps/rrhh/urls.py
from django.urls import path
from . import views

app_name = "rrhh"

urlpatterns = [
    # Dashboard
    path("",                               views.dashboard_rrhh,          name="dashboard"),

    # Departamentos
    path("departamentos/",                 views.departamento_list,        name="departamento_list"),
    path("departamentos/nuevo/",           views.departamento_create,      name="departamento_create"),
    path("departamentos/<int:pk>/editar/", views.departamento_edit,        name="departamento_edit"),

    # Cargos
    path("cargos/",                        views.cargo_list,               name="cargo_list"),
    path("cargos/nuevo/",                  views.cargo_create,             name="cargo_create"),
    path("cargos/<int:pk>/editar/",        views.cargo_edit,               name="cargo_edit"),

    # Empleados
    path("empleados/",                     views.empleado_list,            name="empleado_list"),
    path("empleados/nuevo/",               views.empleado_create,          name="empleado_create"),
    path("empleados/<int:pk>/",            views.empleado_detail,          name="empleado_detail"),
    path("empleados/<int:pk>/editar/",     views.empleado_edit,            name="empleado_edit"),
    path("empleados/<int:pk>/baja/",       views.empleado_delete,          name="empleado_delete"),

    # Vacaciones
    path("vacaciones/",                    views.vacacion_list,            name="vacacion_list"),
    path("vacaciones/nueva/",              views.vacacion_create,          name="vacacion_create"),
    path("vacaciones/<int:pk>/gestionar/", views.vacacion_aprobar,         name="vacacion_aprobar"),

    # Nómina
    path("nominas/",                       views.nomina_list,              name="nomina_list"),
    path("nominas/nueva/",                 views.nomina_create,            name="nomina_create"),
    path("nominas/<int:pk>/",              views.nomina_detail,            name="nomina_detail"),
    path("nominas/<int:pk>/agregar/",      views.nomina_agregar_empleado,  name="nomina_agregar_empleado"),
    path("nominas/<int:pk>/calcular/",     views.nomina_calcular,          name="nomina_calcular"),
    path("nominas/<int:pk>/aprobar/",      views.nomina_aprobar,           name="nomina_aprobar"),
    path("nominas/<int:pk>/pagar/",        views.nomina_pagar,             name="nomina_pagar"),
]
