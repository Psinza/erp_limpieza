# apps/rrhh/admin.py
from django.contrib import admin
from .models import Departamento, Cargo, Empleado, Vacacion, Nomina, DetalleNomina


@admin.register(Departamento)
class DepartamentoAdmin(admin.ModelAdmin):
    list_display  = ["nombre", "activo", "creado_en"]
    list_filter   = ["activo"]
    search_fields = ["nombre"]


@admin.register(Cargo)
class CargoAdmin(admin.ModelAdmin):
    list_display  = ["nombre", "departamento", "salario_base", "activo"]
    list_filter   = ["departamento", "activo"]
    search_fields = ["nombre"]


class DetalleNominaInline(admin.TabularInline):
    model           = DetalleNomina
    extra           = 0
    fields          = ["empleado", "salario_bruto", "bonificaciones", "total_deducciones", "salario_neto"]
    readonly_fields = ["total_deducciones", "salario_neto"]


@admin.register(Empleado)
class EmpleadoAdmin(admin.ModelAdmin):
    list_display    = ["cedula", "apellidos", "nombres", "cargo", "estado", "fecha_ingreso"]
    list_filter     = ["estado", "tipo_contrato", "cargo__departamento"]
    search_fields   = ["cedula", "nombres", "apellidos"]
    readonly_fields = ["creado_en", "modificado_en"]


@admin.register(Vacacion)
class VacacionAdmin(admin.ModelAdmin):
    list_display = ["empleado", "fecha_inicio", "fecha_fin", "dias_solicitados", "estado"]
    list_filter  = ["estado"]


@admin.register(Nomina)
class NominaAdmin(admin.ModelAdmin):
    list_display = ["periodo", "estado", "total_bruto", "total_deducciones", "total_neto"]
    list_filter  = ["estado"]
    inlines      = [DetalleNominaInline]


@admin.register(DetalleNomina)
class DetalleNominaAdmin(admin.ModelAdmin):
    list_display    = ["nomina", "empleado", "salario_bruto", "total_deducciones", "salario_neto"]
    readonly_fields = ["total_deducciones", "salario_neto"]
