# apps/tesoreria/models.py
from django.db import models
from django.contrib.auth import get_user_model
from django.core.validators import MinValueValidator
from decimal import Decimal

User = get_user_model()


# ─────────────────────────────────────────────
#  BANCOS Y CUENTAS
# ─────────────────────────────────────────────
class Banco(models.Model):
    nombre      = models.CharField(max_length=150, unique=True)
    codigo      = models.CharField(max_length=20, blank=True)
    pais        = models.CharField(max_length=100, default="Ecuador")
    activo      = models.BooleanField(default=True)

    class Meta:
        verbose_name        = "Banco"
        verbose_name_plural = "Bancos"
        ordering            = ["nombre"]

    def __str__(self):
        return self.nombre


class CuentaBancaria(models.Model):
    TIPO_CHOICES = [
        ("corriente", "Cuenta Corriente"),
        ("ahorros",   "Cuenta de Ahorros"),
        ("inversion", "Cuenta de Inversión"),
    ]
    MONEDA_CHOICES = [
        ("USD", "Dólar (USD)"),
        ("EUR", "Euro (EUR)"),
        ("GBP", "Libra Esterlina (GBP)"),
    ]

    banco           = models.ForeignKey(
        Banco, on_delete=models.PROTECT, related_name="cuentas"
    )
    numero          = models.CharField(max_length=30, unique=True, verbose_name="N° de Cuenta")
    alias           = models.CharField(max_length=100, help_text="Nombre descriptivo interno")
    tipo            = models.CharField(max_length=12, choices=TIPO_CHOICES, default="corriente")
    moneda          = models.CharField(max_length=5,  choices=MONEDA_CHOICES, default="USD")
    saldo_inicial   = models.DecimalField(
        max_digits=14, decimal_places=2, default=Decimal("0.00")
    )
    saldo_actual    = models.DecimalField(
        max_digits=14, decimal_places=2, default=Decimal("0.00")
    )
    titular         = models.CharField(max_length=200, blank=True)
    activa          = models.BooleanField(default=True)
    creado_en       = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name        = "Cuenta Bancaria"
        verbose_name_plural = "Cuentas Bancarias"
        ordering            = ["banco", "alias"]

    def __str__(self):
        return f"{self.alias} — {self.banco} ({self.numero[-4:]})"


class MovimientoBancario(models.Model):
    TIPO_CHOICES = [
        ("credito", "Crédito (Ingreso)"),
        ("debito",  "Débito (Egreso)"),
    ]
    CONCEPTO_CHOICES = [
        ("cobro",          "Cobro a cliente"),
        ("pago_proveedor", "Pago a proveedor"),
        ("pago_nomina",    "Pago de nómina"),
        ("transferencia",  "Transferencia entre cuentas"),
        ("comision",       "Comisión bancaria"),
        ("intereses",      "Intereses"),
        ("impuesto",       "Impuesto / retención"),
        ("otro",           "Otro"),
    ]

    cuenta          = models.ForeignKey(
        CuentaBancaria, on_delete=models.PROTECT, related_name="movimientos"
    )
    fecha           = models.DateField()
    tipo            = models.CharField(max_length=8, choices=TIPO_CHOICES)
    concepto        = models.CharField(max_length=20, choices=CONCEPTO_CHOICES, default="otro")
    descripcion     = models.CharField(max_length=300)
    referencia      = models.CharField(max_length=100, blank=True,
                                       help_text="N° cheque, transferencia, etc.")
    monto           = models.DecimalField(
        max_digits=14, decimal_places=2,
        validators=[MinValueValidator(Decimal("0.01"))]
    )
    saldo_posterior = models.DecimalField(
        max_digits=14, decimal_places=2, default=Decimal("0.00")
    )
    conciliado      = models.BooleanField(default=False)
    creado_por      = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, related_name="mov_bancarios"
    )
    creado_en       = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name        = "Movimiento Bancario"
        verbose_name_plural = "Movimientos Bancarios"
        ordering            = ["-fecha", "-creado_en"]

    def __str__(self):
        return f"{self.fecha} | {self.cuenta.alias} | {self.get_tipo_display()} ${self.monto}"

    def save(self, *args, **kwargs):
        cuenta = self.cuenta
        if not self.pk:  # Solo al crear
            if self.tipo == "credito":
                cuenta.saldo_actual += self.monto
            else:
                cuenta.saldo_actual -= self.monto
            self.saldo_posterior = cuenta.saldo_actual
            cuenta.save()
        super().save(*args, **kwargs)


# ─────────────────────────────────────────────
#  CAJA CHICA
# ─────────────────────────────────────────────
class Caja(models.Model):
    nombre          = models.CharField(max_length=100, unique=True)
    responsable     = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, related_name="cajas"
    )
    monto_asignado  = models.DecimalField(
        max_digits=12, decimal_places=2, default=Decimal("0.00")
    )
    saldo_actual    = models.DecimalField(
        max_digits=12, decimal_places=2, default=Decimal("0.00")
    )
    activa          = models.BooleanField(default=True)
    creado_en       = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name        = "Caja"
        verbose_name_plural = "Cajas"
        ordering            = ["nombre"]

    def __str__(self):
        return f"{self.nombre} (Saldo: ${self.saldo_actual})"


class MovimientoCaja(models.Model):
    TIPO_CHOICES = [
        ("ingreso", "Ingreso"),
        ("egreso",  "Egreso"),
    ]

    caja            = models.ForeignKey(
        Caja, on_delete=models.PROTECT, related_name="movimientos"
    )
    fecha           = models.DateField()
    tipo            = models.CharField(max_length=8, choices=TIPO_CHOICES)
    descripcion     = models.CharField(max_length=300)
    monto           = models.DecimalField(
        max_digits=12, decimal_places=2,
        validators=[MinValueValidator(Decimal("0.01"))]
    )
    comprobante     = models.CharField(max_length=100, blank=True)
    saldo_posterior = models.DecimalField(
        max_digits=12, decimal_places=2, default=Decimal("0.00")
    )
    creado_por      = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, related_name="mov_caja"
    )
    creado_en       = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name        = "Movimiento de Caja"
        verbose_name_plural = "Movimientos de Caja"
        ordering            = ["-fecha", "-creado_en"]

    def __str__(self):
        return f"{self.fecha} | {self.caja.nombre} | {self.get_tipo_display()} ${self.monto}"

    def save(self, *args, **kwargs):
        caja = self.caja
        if not self.pk:
            if self.tipo == "ingreso":
                caja.saldo_actual += self.monto
            else:
                caja.saldo_actual -= self.monto
            self.saldo_posterior = caja.saldo_actual
            caja.save()
        super().save(*args, **kwargs)


# ─────────────────────────────────────────────
#  CUENTAS POR COBRAR
# ─────────────────────────────────────────────
class CuentaPorCobrar(models.Model):
    ESTADO_CHOICES = [
        ("pendiente", "Pendiente"),
        ("parcial",   "Cobrado Parcialmente"),
        ("cobrado",   "Cobrado"),
        ("vencido",   "Vencido"),
        ("anulado",   "Anulado"),
    ]

    numero          = models.CharField(max_length=20, unique=True)
    cliente_nombre  = models.CharField(max_length=200, verbose_name="Cliente")
    cliente_ruc     = models.CharField(max_length=20, blank=True, verbose_name="RUC/Cédula")
    concepto        = models.CharField(max_length=300)
    referencia      = models.CharField(max_length=100, blank=True,
                                       help_text="N° factura, pedido, etc.")
    fecha_emision   = models.DateField()
    fecha_vencimiento = models.DateField()
    monto_total     = models.DecimalField(
        max_digits=14, decimal_places=2,
        validators=[MinValueValidator(Decimal("0.01"))]
    )
    monto_cobrado   = models.DecimalField(
        max_digits=14, decimal_places=2, default=Decimal("0.00")
    )
    estado          = models.CharField(max_length=10, choices=ESTADO_CHOICES, default="pendiente")
    observaciones   = models.TextField(blank=True)
    creado_por      = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, related_name="cxc_creadas"
    )
    creado_en       = models.DateTimeField(auto_now_add=True)
    modificado_en   = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name        = "Cuenta por Cobrar"
        verbose_name_plural = "Cuentas por Cobrar"
        ordering            = ["fecha_vencimiento", "-fecha_emision"]

    def __str__(self):
        return f"CXC-{self.numero} | {self.cliente_nombre} | ${self.saldo_pendiente}"

    @property
    def saldo_pendiente(self):
        return self.monto_total - self.monto_cobrado

    @property
    def esta_vencida(self):
        from django.utils import timezone
        return self.fecha_vencimiento < timezone.now().date() and self.estado in ["pendiente", "parcial"]

    @classmethod
    def generar_numero(cls):
        from django.utils import timezone
        year  = timezone.now().year
        ultimo = cls.objects.filter(numero__startswith=str(year)).order_by("-numero").first()
        seq = 1
        if ultimo:
            try:
                seq = int(ultimo.numero.split("-")[-1]) + 1
            except (ValueError, IndexError):
                pass
        return f"{year}-{seq:04d}"


# ─────────────────────────────────────────────
#  CUENTAS POR PAGAR
# ─────────────────────────────────────────────
class CuentaPorPagar(models.Model):
    ESTADO_CHOICES = [
        ("pendiente", "Pendiente"),
        ("parcial",   "Pagado Parcialmente"),
        ("pagado",    "Pagado"),
        ("vencido",   "Vencido"),
        ("anulado",   "Anulado"),
    ]

    numero          = models.CharField(max_length=20, unique=True)
    proveedor_nombre= models.CharField(max_length=200, verbose_name="Proveedor")
    proveedor_ruc   = models.CharField(max_length=20, blank=True, verbose_name="RUC/NIT")
    concepto        = models.CharField(max_length=300)
    referencia      = models.CharField(max_length=100, blank=True,
                                       help_text="N° factura proveedor, OC, etc.")
    fecha_emision   = models.DateField()
    fecha_vencimiento = models.DateField()
    monto_total     = models.DecimalField(
        max_digits=14, decimal_places=2,
        validators=[MinValueValidator(Decimal("0.01"))]
    )
    monto_pagado    = models.DecimalField(
        max_digits=14, decimal_places=2, default=Decimal("0.00")
    )
    estado          = models.CharField(max_length=10, choices=ESTADO_CHOICES, default="pendiente")
    observaciones   = models.TextField(blank=True)
    creado_por      = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, related_name="cxp_creadas"
    )
    creado_en       = models.DateTimeField(auto_now_add=True)
    modificado_en   = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name        = "Cuenta por Pagar"
        verbose_name_plural = "Cuentas por Pagar"
        ordering            = ["fecha_vencimiento", "-fecha_emision"]

    def __str__(self):
        return f"CXP-{self.numero} | {self.proveedor_nombre} | ${self.saldo_pendiente}"

    @property
    def saldo_pendiente(self):
        return self.monto_total - self.monto_pagado

    @property
    def esta_vencida(self):
        from django.utils import timezone
        return self.fecha_vencimiento < timezone.now().date() and self.estado in ["pendiente", "parcial"]

    @classmethod
    def generar_numero(cls):
        from django.utils import timezone
        year  = timezone.now().year
        ultimo = cls.objects.filter(numero__startswith=str(year)).order_by("-numero").first()
        seq = 1
        if ultimo:
            try:
                seq = int(ultimo.numero.split("-")[-1]) + 1
            except (ValueError, IndexError):
                pass
        return f"{year}-{seq:04d}"


# ─────────────────────────────────────────────
#  COBROS (contra CXC)
# ─────────────────────────────────────────────
class Cobro(models.Model):
    MEDIO_CHOICES = [
        ("efectivo",       "Efectivo"),
        ("transferencia",  "Transferencia Bancaria"),
        ("cheque",         "Cheque"),
        ("tarjeta",        "Tarjeta de Crédito/Débito"),
        ("deposito",       "Depósito Bancario"),
    ]

    cxc             = models.ForeignKey(
        CuentaPorCobrar, on_delete=models.PROTECT, related_name="cobros"
    )
    fecha           = models.DateField()
    monto           = models.DecimalField(
        max_digits=14, decimal_places=2,
        validators=[MinValueValidator(Decimal("0.01"))]
    )
    medio_pago      = models.CharField(max_length=15, choices=MEDIO_CHOICES)
    cuenta_bancaria = models.ForeignKey(
        CuentaBancaria, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="cobros"
    )
    referencia      = models.CharField(max_length=100, blank=True)
    observaciones   = models.CharField(max_length=300, blank=True)
    creado_por      = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, related_name="cobros_registrados"
    )
    creado_en       = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name        = "Cobro"
        verbose_name_plural = "Cobros"
        ordering            = ["-fecha"]

    def __str__(self):
        return f"COBRO | CXC-{self.cxc.numero} | ${self.monto} | {self.fecha}"

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        # Actualizar CXC
        cxc = self.cxc
        total_cobrado = cxc.cobros.aggregate(
            total=models.Sum("monto")
        )["total"] or Decimal("0.00")
        cxc.monto_cobrado = total_cobrado
        if cxc.monto_cobrado >= cxc.monto_total:
            cxc.estado = "cobrado"
        elif cxc.monto_cobrado > 0:
            cxc.estado = "parcial"
        cxc.save()
        # Registrar en cuenta bancaria si aplica
        if self.cuenta_bancaria and not self.pk == self._state.adding:
            pass  # El movimiento bancario se crea por separado


# ─────────────────────────────────────────────
#  PAGOS (contra CXP)
# ─────────────────────────────────────────────
class Pago(models.Model):
    MEDIO_CHOICES = [
        ("efectivo",      "Efectivo"),
        ("transferencia", "Transferencia Bancaria"),
        ("cheque",        "Cheque"),
        ("tarjeta",       "Tarjeta"),
    ]

    cxp             = models.ForeignKey(
        CuentaPorPagar, on_delete=models.PROTECT, related_name="pagos"
    )
    fecha           = models.DateField()
    monto           = models.DecimalField(
        max_digits=14, decimal_places=2,
        validators=[MinValueValidator(Decimal("0.01"))]
    )
    medio_pago      = models.CharField(max_length=15, choices=MEDIO_CHOICES)
    cuenta_bancaria = models.ForeignKey(
        CuentaBancaria, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="pagos"
    )
    referencia      = models.CharField(max_length=100, blank=True)
    observaciones   = models.CharField(max_length=300, blank=True)
    creado_por      = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, related_name="pagos_registrados"
    )
    creado_en       = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name        = "Pago"
        verbose_name_plural = "Pagos"
        ordering            = ["-fecha"]

    def __str__(self):
        return f"PAGO | CXP-{self.cxp.numero} | ${self.monto} | {self.fecha}"

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        # Actualizar CXP
        cxp = self.cxp
        total_pagado = cxp.pagos.aggregate(
            total=models.Sum("monto")
        )["total"] or Decimal("0.00")
        cxp.monto_pagado = total_pagado
        if cxp.monto_pagado >= cxp.monto_total:
            cxp.estado = "pagado"
        elif cxp.monto_pagado > 0:
            cxp.estado = "parcial"
        cxp.save()


# ─────────────────────────────────────────────
#  TRANSFERENCIAS ENTRE CUENTAS
# ─────────────────────────────────────────────
class TransferenciaBancaria(models.Model):
    ESTADO_CHOICES = [
        ("pendiente",  "Pendiente"),
        ("completada", "Completada"),
        ("rechazada",  "Rechazada"),
    ]

    cuenta_origen   = models.ForeignKey(
        CuentaBancaria, on_delete=models.PROTECT,
        related_name="transferencias_enviadas"
    )
    cuenta_destino  = models.ForeignKey(
        CuentaBancaria, on_delete=models.PROTECT,
        related_name="transferencias_recibidas"
    )
    fecha           = models.DateField()
    monto           = models.DecimalField(
        max_digits=14, decimal_places=2,
        validators=[MinValueValidator(Decimal("0.01"))]
    )
    descripcion     = models.CharField(max_length=300)
    referencia      = models.CharField(max_length=100, blank=True)
    estado          = models.CharField(max_length=10, choices=ESTADO_CHOICES, default="pendiente")
    creado_por      = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, related_name="transferencias"
    )
    creado_en       = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name        = "Transferencia Bancaria"
        verbose_name_plural = "Transferencias Bancarias"
        ordering            = ["-fecha"]

    def __str__(self):
        return (
            f"{self.fecha} | {self.cuenta_origen.alias} → "
            f"{self.cuenta_destino.alias} | ${self.monto}"
        )

    def ejecutar(self):
        """Aplica la transferencia debitando origen y acreditando destino."""
        if self.estado != "pendiente":
            return False
        MovimientoBancario.objects.create(
            cuenta=self.cuenta_origen,
            fecha=self.fecha,
            tipo="debito",
            concepto="transferencia",
            descripcion=f"Transferencia a {self.cuenta_destino.alias}",
            referencia=self.referencia,
            monto=self.monto,
            creado_por=self.creado_por,
        )
        MovimientoBancario.objects.create(
            cuenta=self.cuenta_destino,
            fecha=self.fecha,
            tipo="credito",
            concepto="transferencia",
            descripcion=f"Transferencia desde {self.cuenta_origen.alias}",
            referencia=self.referencia,
            monto=self.monto,
            creado_por=self.creado_por,
        )
        self.estado = "completada"
        self.save()
        return True
