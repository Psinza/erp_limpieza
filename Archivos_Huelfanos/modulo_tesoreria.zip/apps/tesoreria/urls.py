# apps/tesoreria/urls.py
from django.urls import path
from . import views

app_name = "tesoreria"

urlpatterns = [
    # Dashboard
    path("",                                          views.dashboard_tesoreria,        name="dashboard"),

    # Bancos
    path("bancos/",                                   views.banco_list,                 name="banco_list"),
    path("bancos/nuevo/",                             views.banco_create,               name="banco_create"),
    path("bancos/<int:pk>/editar/",                   views.banco_edit,                 name="banco_edit"),

    # Cuentas bancarias
    path("cuentas/",                                  views.cuenta_list,                name="cuenta_list"),
    path("cuentas/nueva/",                            views.cuenta_create,              name="cuenta_create"),
    path("cuentas/<int:pk>/",                         views.cuenta_detail,              name="cuenta_detail"),
    path("cuentas/<int:pk>/editar/",                  views.cuenta_edit,                name="cuenta_edit"),

    # Movimientos bancarios
    path("movimientos/nuevo/",                        views.movimiento_bancario_create, name="movimiento_bancario_create"),

    # Cajas
    path("cajas/",                                    views.caja_list,                  name="caja_list"),
    path("cajas/nueva/",                              views.caja_create,                name="caja_create"),
    path("cajas/<int:pk>/",                           views.caja_detail,                name="caja_detail"),
    path("cajas/movimiento/nuevo/",                   views.movimiento_caja_create,     name="movimiento_caja_create"),

    # Cuentas por Cobrar
    path("cxc/",                                      views.cxc_list,                   name="cxc_list"),
    path("cxc/nueva/",                                views.cxc_create,                 name="cxc_create"),
    path("cxc/<int:pk>/",                             views.cxc_detail,                 name="cxc_detail"),
    path("cxc/<int:pk>/cobro/",                       views.cxc_registrar_cobro,        name="cxc_registrar_cobro"),
    path("cxc/<int:pk>/anular/",                      views.cxc_anular,                 name="cxc_anular"),

    # Cuentas por Pagar
    path("cxp/",                                      views.cxp_list,                   name="cxp_list"),
    path("cxp/nueva/",                                views.cxp_create,                 name="cxp_create"),
    path("cxp/<int:pk>/",                             views.cxp_detail,                 name="cxp_detail"),
    path("cxp/<int:pk>/pago/",                        views.cxp_registrar_pago,         name="cxp_registrar_pago"),
    path("cxp/<int:pk>/anular/",                      views.cxp_anular,                 name="cxp_anular"),

    # Transferencias
    path("transferencias/",                           views.transferencia_list,          name="transferencia_list"),
    path("transferencias/nueva/",                     views.transferencia_create,        name="transferencia_create"),
    path("transferencias/<int:pk>/ejecutar/",         views.transferencia_ejecutar,      name="transferencia_ejecutar"),

    # Flujo de caja
    path("flujo-caja/",                               views.flujo_caja,                 name="flujo_caja"),
]
