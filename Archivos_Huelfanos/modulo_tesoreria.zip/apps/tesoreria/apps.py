from django.apps import AppConfig


class TesoreriaConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name               = "apps.tesoreria"
    verbose_name       = "Tesorería — Bancos, Pagos y Cobros"
