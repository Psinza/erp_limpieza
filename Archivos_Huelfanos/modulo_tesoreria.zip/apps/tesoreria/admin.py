# apps/tesoreria/admin.py
from django.contrib import admin
from .models import (
    Banco, CuentaBancaria, MovimientoBancario,
    Caja, MovimientoCaja,
    CuentaPorCobrar, CuentaPorPagar,
    Cobro, Pago, TransferenciaBancaria,
)


@admin.register(Banco)
class BancoAdmin(admin.ModelAdmin):
    list_display  = ["nombre", "codigo", "pais", "activo"]
    search_fields = ["nombre"]


class MovimientoBancarioInline(admin.TabularInline):
    model           = MovimientoBancario
    extra           = 0
    fields          = ["fecha", "tipo", "concepto", "descripcion", "monto", "saldo_posterior", "conciliado"]
    readonly_fields = ["saldo_posterior"]


@admin.register(CuentaBancaria)
class CuentaBancariaAdmin(admin.ModelAdmin):
    list_display    = ["alias", "banco", "tipo", "moneda", "saldo_actual", "activa"]
    list_filter     = ["banco", "tipo", "activa"]
    readonly_fields = ["saldo_actual"]
    inlines         = [MovimientoBancarioInline]


@admin.register(MovimientoBancario)
class MovimientoBancarioAdmin(admin.ModelAdmin):
    list_display    = ["fecha", "cuenta", "tipo", "concepto", "monto", "saldo_posterior", "conciliado"]
    list_filter     = ["tipo", "concepto", "conciliado"]
    readonly_fields = ["saldo_posterior"]
    date_hierarchy  = "fecha"


class MovimientoCajaInline(admin.TabularInline):
    model           = MovimientoCaja
    extra           = 0
    fields          = ["fecha", "tipo", "descripcion", "monto", "saldo_posterior"]
    readonly_fields = ["saldo_posterior"]


@admin.register(Caja)
class CajaAdmin(admin.ModelAdmin):
    list_display = ["nombre", "responsable", "monto_asignado", "saldo_actual", "activa"]
    inlines      = [MovimientoCajaInline]


class CobroInline(admin.TabularInline):
    model  = Cobro
    extra  = 0
    fields = ["fecha", "monto", "medio_pago", "referencia"]


@admin.register(CuentaPorCobrar)
class CuentaPorCobrarAdmin(admin.ModelAdmin):
    list_display    = ["numero", "cliente_nombre", "monto_total",
                       "monto_cobrado", "estado", "fecha_vencimiento"]
    list_filter     = ["estado"]
    search_fields   = ["numero", "cliente_nombre"]
    readonly_fields = ["numero", "monto_cobrado"]
    inlines         = [CobroInline]


class PagoInline(admin.TabularInline):
    model  = Pago
    extra  = 0
    fields = ["fecha", "monto", "medio_pago", "referencia"]


@admin.register(CuentaPorPagar)
class CuentaPorPagarAdmin(admin.ModelAdmin):
    list_display    = ["numero", "proveedor_nombre", "monto_total",
                       "monto_pagado", "estado", "fecha_vencimiento"]
    list_filter     = ["estado"]
    search_fields   = ["numero", "proveedor_nombre"]
    readonly_fields = ["numero", "monto_pagado"]
    inlines         = [PagoInline]


@admin.register(TransferenciaBancaria)
class TransferenciaAdmin(admin.ModelAdmin):
    list_display = ["fecha", "cuenta_origen", "cuenta_destino", "monto", "estado"]
    list_filter  = ["estado"]
