# apps/tesoreria/views.py
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q, Sum
from django.utils import timezone
from decimal import Decimal

from .models import (
    Banco, CuentaBancaria, MovimientoBancario,
    Caja, MovimientoCaja,
    CuentaPorCobrar, CuentaPorPagar,
    Cobro, Pago, TransferenciaBancaria,
)
from .forms import (
    BancoForm, CuentaBancariaForm, MovimientoBancarioForm,
    CajaForm, MovimientoCajaForm,
    CuentaPorCobrarForm, CuentaPorPagarForm,
    CobroForm, PagoForm, TransferenciaBancariaForm,
)


# ─────────────────────────────────────────────
#  DASHBOARD
# ─────────────────────────────────────────────
@login_required
def dashboard_tesoreria(request):
    total_bancos  = CuentaBancaria.objects.filter(activa=True).aggregate(
        total=Sum("saldo_actual")
    )["total"] or Decimal("0.00")
    total_cajas   = Caja.objects.filter(activa=True).aggregate(
        total=Sum("saldo_actual")
    )["total"] or Decimal("0.00")
    total_cxc     = CuentaPorCobrar.objects.filter(
        estado__in=["pendiente", "parcial"]
    ).aggregate(total=Sum("monto_total") - Sum("monto_cobrado"))["total"] or Decimal("0.00")
    total_cxp     = CuentaPorPagar.objects.filter(
        estado__in=["pendiente", "parcial"]
    ).aggregate(total=Sum("monto_total") - Sum("monto_pagado"))["total"] or Decimal("0.00")

    cuentas       = CuentaBancaria.objects.select_related("banco").filter(activa=True)
    cxc_vencidas  = CuentaPorCobrar.objects.filter(
        estado__in=["pendiente", "parcial"],
        fecha_vencimiento__lt=timezone.now().date()
    ).count()
    cxp_vencidas  = CuentaPorPagar.objects.filter(
        estado__in=["pendiente", "parcial"],
        fecha_vencimiento__lt=timezone.now().date()
    ).count()
    ultimos_movimientos = MovimientoBancario.objects.select_related(
        "cuenta"
    ).order_by("-fecha", "-creado_en")[:8]
    proximas_cxc  = CuentaPorCobrar.objects.filter(
        estado__in=["pendiente", "parcial"]
    ).order_by("fecha_vencimiento")[:5]
    proximas_cxp  = CuentaPorPagar.objects.filter(
        estado__in=["pendiente", "parcial"]
    ).order_by("fecha_vencimiento")[:5]

    return render(request, "tesoreria/dashboard_tesoreria.html", {
        "total_bancos":       total_bancos,
        "total_cajas":        total_cajas,
        "total_cxc":          total_cxc,
        "total_cxp":          total_cxp,
        "cuentas":            cuentas,
        "cxc_vencidas":       cxc_vencidas,
        "cxp_vencidas":       cxp_vencidas,
        "ultimos_movimientos":ultimos_movimientos,
        "proximas_cxc":       proximas_cxc,
        "proximas_cxp":       proximas_cxp,
        "liquidez":           total_bancos + total_cajas,
    })


# ─────────────────────────────────────────────
#  BANCOS
# ─────────────────────────────────────────────
@login_required
def banco_list(request):
    bancos = Banco.objects.annotate(num_cuentas=Sum("cuentas__saldo_actual"))
    return render(request, "tesoreria/banco_list.html", {"bancos": bancos})


@login_required
def banco_create(request):
    form = BancoForm(request.POST or None)
    if form.is_valid():
        form.save()
        messages.success(request, "Banco creado.")
        return redirect("tesoreria:banco_list")
    return render(request, "tesoreria/banco_form.html",
                  {"form": form, "titulo": "Nuevo Banco"})


@login_required
def banco_edit(request, pk):
    banco = get_object_or_404(Banco, pk=pk)
    form  = BancoForm(request.POST or None, instance=banco)
    if form.is_valid():
        form.save()
        messages.success(request, "Banco actualizado.")
        return redirect("tesoreria:banco_list")
    return render(request, "tesoreria/banco_form.html",
                  {"form": form, "titulo": "Editar Banco"})


# ─────────────────────────────────────────────
#  CUENTAS BANCARIAS
# ─────────────────────────────────────────────
@login_required
def cuenta_list(request):
    cuentas = CuentaBancaria.objects.select_related("banco").filter(activa=True)
    total   = cuentas.aggregate(total=Sum("saldo_actual"))["total"] or Decimal("0.00")
    return render(request, "tesoreria/cuenta_list.html",
                  {"cuentas": cuentas, "total": total})


@login_required
def cuenta_create(request):
    form = CuentaBancariaForm(request.POST or None)
    if form.is_valid():
        cuenta = form.save(commit=False)
        cuenta.saldo_actual = cuenta.saldo_inicial
        cuenta.save()
        messages.success(request, f"Cuenta '{cuenta.alias}' creada.")
        return redirect("tesoreria:cuenta_detail", pk=cuenta.pk)
    return render(request, "tesoreria/cuenta_form.html",
                  {"form": form, "titulo": "Nueva Cuenta Bancaria"})


@login_required
def cuenta_detail(request, pk):
    cuenta = get_object_or_404(CuentaBancaria, pk=pk)
    movs   = cuenta.movimientos.order_by("-fecha", "-creado_en")[:20]
    mov_form = MovimientoBancarioForm(initial={"cuenta": cuenta})
    return render(request, "tesoreria/cuenta_detail.html", {
        "cuenta": cuenta, "movimientos": movs, "mov_form": mov_form,
    })


@login_required
def cuenta_edit(request, pk):
    cuenta = get_object_or_404(CuentaBancaria, pk=pk)
    form   = CuentaBancariaForm(request.POST or None, instance=cuenta)
    if form.is_valid():
        form.save()
        messages.success(request, "Cuenta actualizada.")
        return redirect("tesoreria:cuenta_detail", pk=pk)
    return render(request, "tesoreria/cuenta_form.html",
                  {"form": form, "titulo": "Editar Cuenta", "cuenta": cuenta})


@login_required
def movimiento_bancario_create(request):
    form = MovimientoBancarioForm(request.POST or None)
    if form.is_valid():
        mov = form.save(commit=False)
        mov.creado_por = request.user
        mov.save()
        messages.success(request,
            f"Movimiento registrado: {mov.get_tipo_display()} ${mov.monto}")
        return redirect("tesoreria:cuenta_detail", pk=mov.cuenta.pk)
    cuenta_pk = request.POST.get("cuenta") or request.GET.get("cuenta")
    return render(request, "tesoreria/movimiento_bancario_form.html", {
        "form": form,
        "cuenta_pk": cuenta_pk,
    })


# ─────────────────────────────────────────────
#  CAJAS
# ─────────────────────────────────────────────
@login_required
def caja_list(request):
    cajas = Caja.objects.filter(activa=True)
    total = cajas.aggregate(total=Sum("saldo_actual"))["total"] or Decimal("0.00")
    return render(request, "tesoreria/caja_list.html",
                  {"cajas": cajas, "total": total})


@login_required
def caja_create(request):
    form = CajaForm(request.POST or None)
    if form.is_valid():
        caja = form.save(commit=False)
        caja.saldo_actual = caja.monto_asignado
        caja.save()
        messages.success(request, f"Caja '{caja.nombre}' creada.")
        return redirect("tesoreria:caja_detail", pk=caja.pk)
    return render(request, "tesoreria/caja_form.html",
                  {"form": form, "titulo": "Nueva Caja"})


@login_required
def caja_detail(request, pk):
    caja = get_object_or_404(Caja, pk=pk)
    movs = caja.movimientos.order_by("-fecha", "-creado_en")[:20]
    mov_form = MovimientoCajaForm(initial={"caja": caja})
    return render(request, "tesoreria/caja_detail.html", {
        "caja": caja, "movimientos": movs, "mov_form": mov_form,
    })


@login_required
def movimiento_caja_create(request):
    form = MovimientoCajaForm(request.POST or None)
    if form.is_valid():
        mov = form.save(commit=False)
        mov.creado_por = request.user
        mov.save()
        messages.success(request,
            f"Movimiento registrado: {mov.get_tipo_display()} ${mov.monto}")
        return redirect("tesoreria:caja_detail", pk=mov.caja.pk)
    return render(request, "tesoreria/movimiento_caja_form.html", {"form": form})


# ─────────────────────────────────────────────
#  CUENTAS POR COBRAR
# ─────────────────────────────────────────────
@login_required
def cxc_list(request):
    q      = request.GET.get("q", "")
    estado = request.GET.get("estado", "")
    qs     = CuentaPorCobrar.objects.all()
    if q:
        qs = qs.filter(
            Q(cliente_nombre__icontains=q) |
            Q(numero__icontains=q)         |
            Q(referencia__icontains=q)
        )
    if estado:
        qs = qs.filter(estado=estado)

    resumen = qs.aggregate(
        total=Sum("monto_total"),
        cobrado=Sum("monto_cobrado"),
    )
    return render(request, "tesoreria/cxc_list.html", {
        "cxc_list": qs, "q": q, "estado": estado,
        "estados": CuentaPorCobrar.ESTADO_CHOICES,
        "resumen": resumen,
    })


@login_required
def cxc_create(request):
    form = CuentaPorCobrarForm(request.POST or None)
    if form.is_valid():
        cxc = form.save(commit=False)
        cxc.numero     = CuentaPorCobrar.generar_numero()
        cxc.creado_por = request.user
        cxc.save()
        messages.success(request, f"CXC-{cxc.numero} creada.")
        return redirect("tesoreria:cxc_detail", pk=cxc.pk)
    return render(request, "tesoreria/cxc_form.html",
                  {"form": form, "titulo": "Nueva Cuenta por Cobrar"})


@login_required
def cxc_detail(request, pk):
    cxc     = get_object_or_404(CuentaPorCobrar, pk=pk)
    cobros  = cxc.cobros.order_by("-fecha")
    cobro_form = CobroForm()
    return render(request, "tesoreria/cxc_detail.html", {
        "cxc": cxc, "cobros": cobros, "cobro_form": cobro_form,
    })


@login_required
def cxc_registrar_cobro(request, pk):
    cxc = get_object_or_404(CuentaPorCobrar, pk=pk)
    if cxc.estado in ["cobrado", "anulado"]:
        messages.error(request, "Esta CXC ya está cobrada o anulada.")
        return redirect("tesoreria:cxc_detail", pk=pk)
    form = CobroForm(request.POST)
    if form.is_valid():
        cobro = form.save(commit=False)
        cobro.cxc        = cxc
        cobro.creado_por = request.user
        if cobro.monto > cxc.saldo_pendiente:
            messages.error(request,
                f"El monto (${cobro.monto}) supera el saldo pendiente (${cxc.saldo_pendiente}).")
            return redirect("tesoreria:cxc_detail", pk=pk)
        cobro.save()
        # Crear movimiento bancario si hay cuenta
        if cobro.cuenta_bancaria:
            MovimientoBancario.objects.create(
                cuenta=cobro.cuenta_bancaria,
                fecha=cobro.fecha,
                tipo="credito",
                concepto="cobro",
                descripcion=f"Cobro CXC-{cxc.numero} — {cxc.cliente_nombre}",
                referencia=cobro.referencia,
                monto=cobro.monto,
                creado_por=request.user,
            )
        messages.success(request, f"Cobro de ${cobro.monto} registrado.")
    else:
        messages.error(request, f"Error: {form.errors}")
    return redirect("tesoreria:cxc_detail", pk=pk)


@login_required
def cxc_anular(request, pk):
    cxc = get_object_or_404(CuentaPorCobrar, pk=pk)
    if request.method == "POST":
        cxc.estado = "anulado"
        cxc.save()
        messages.warning(request, f"CXC-{cxc.numero} anulada.")
    return redirect("tesoreria:cxc_list")


# ─────────────────────────────────────────────
#  CUENTAS POR PAGAR
# ─────────────────────────────────────────────
@login_required
def cxp_list(request):
    q      = request.GET.get("q", "")
    estado = request.GET.get("estado", "")
    qs     = CuentaPorPagar.objects.all()
    if q:
        qs = qs.filter(
            Q(proveedor_nombre__icontains=q) |
            Q(numero__icontains=q)            |
            Q(referencia__icontains=q)
        )
    if estado:
        qs = qs.filter(estado=estado)

    resumen = qs.aggregate(
        total=Sum("monto_total"),
        pagado=Sum("monto_pagado"),
    )
    return render(request, "tesoreria/cxp_list.html", {
        "cxp_list": qs, "q": q, "estado": estado,
        "estados": CuentaPorPagar.ESTADO_CHOICES,
        "resumen": resumen,
    })


@login_required
def cxp_create(request):
    form = CuentaPorPagarForm(request.POST or None)
    if form.is_valid():
        cxp = form.save(commit=False)
        cxp.numero     = CuentaPorPagar.generar_numero()
        cxp.creado_por = request.user
        cxp.save()
        messages.success(request, f"CXP-{cxp.numero} creada.")
        return redirect("tesoreria:cxp_detail", pk=cxp.pk)
    return render(request, "tesoreria/cxp_form.html",
                  {"form": form, "titulo": "Nueva Cuenta por Pagar"})


@login_required
def cxp_detail(request, pk):
    cxp    = get_object_or_404(CuentaPorPagar, pk=pk)
    pagos  = cxp.pagos.order_by("-fecha")
    pago_form = PagoForm()
    return render(request, "tesoreria/cxp_detail.html", {
        "cxp": cxp, "pagos": pagos, "pago_form": pago_form,
    })


@login_required
def cxp_registrar_pago(request, pk):
    cxp = get_object_or_404(CuentaPorPagar, pk=pk)
    if cxp.estado in ["pagado", "anulado"]:
        messages.error(request, "Esta CXP ya está pagada o anulada.")
        return redirect("tesoreria:cxp_detail", pk=pk)
    form = PagoForm(request.POST)
    if form.is_valid():
        pago = form.save(commit=False)
        pago.cxp        = cxp
        pago.creado_por = request.user
        if pago.monto > cxp.saldo_pendiente:
            messages.error(request,
                f"El monto (${pago.monto}) supera el saldo pendiente (${cxp.saldo_pendiente}).")
            return redirect("tesoreria:cxp_detail", pk=pk)
        pago.save()
        if pago.cuenta_bancaria:
            MovimientoBancario.objects.create(
                cuenta=pago.cuenta_bancaria,
                fecha=pago.fecha,
                tipo="debito",
                concepto="pago_proveedor",
                descripcion=f"Pago CXP-{cxp.numero} — {cxp.proveedor_nombre}",
                referencia=pago.referencia,
                monto=pago.monto,
                creado_por=request.user,
            )
        messages.success(request, f"Pago de ${pago.monto} registrado.")
    else:
        messages.error(request, f"Error: {form.errors}")
    return redirect("tesoreria:cxp_detail", pk=pk)


@login_required
def cxp_anular(request, pk):
    cxp = get_object_or_404(CuentaPorPagar, pk=pk)
    if request.method == "POST":
        cxp.estado = "anulado"
        cxp.save()
        messages.warning(request, f"CXP-{cxp.numero} anulada.")
    return redirect("tesoreria:cxp_list")


# ─────────────────────────────────────────────
#  TRANSFERENCIAS
# ─────────────────────────────────────────────
@login_required
def transferencia_list(request):
    qs = TransferenciaBancaria.objects.select_related(
        "cuenta_origen", "cuenta_destino"
    ).order_by("-fecha")
    return render(request, "tesoreria/transferencia_list.html", {"transferencias": qs})


@login_required
def transferencia_create(request):
    form = TransferenciaBancariaForm(request.POST or None)
    if form.is_valid():
        transf = form.save(commit=False)
        transf.creado_por = request.user
        transf.save()
        messages.success(request, f"Transferencia creada por ${transf.monto}.")
        return redirect("tesoreria:transferencia_ejecutar", pk=transf.pk)
    return render(request, "tesoreria/transferencia_form.html", {"form": form})


@login_required
def transferencia_ejecutar(request, pk):
    transf = get_object_or_404(TransferenciaBancaria, pk=pk)
    if request.method == "POST":
        if transf.ejecutar():
            messages.success(request,
                f"Transferencia ejecutada: ${transf.monto} de "
                f"{transf.cuenta_origen.alias} → {transf.cuenta_destino.alias}")
        else:
            messages.error(request, "No se pudo ejecutar la transferencia.")
    return redirect("tesoreria:transferencia_list")


# ─────────────────────────────────────────────
#  FLUJO DE CAJA (reporte)
# ─────────────────────────────────────────────
@login_required
def flujo_caja(request):
    from datetime import date, timedelta
    hoy       = timezone.now().date()
    inicio    = request.GET.get("inicio", str(hoy.replace(day=1)))
    fin       = request.GET.get("fin",    str(hoy))

    mov_banco = MovimientoBancario.objects.filter(
        fecha__range=[inicio, fin]
    ).select_related("cuenta").order_by("fecha")

    mov_caja  = MovimientoCaja.objects.filter(
        fecha__range=[inicio, fin]
    ).select_related("caja").order_by("fecha")

    ingresos_banco = mov_banco.filter(tipo="credito").aggregate(
        total=Sum("monto"))["total"] or Decimal("0.00")
    egresos_banco  = mov_banco.filter(tipo="debito").aggregate(
        total=Sum("monto"))["total"] or Decimal("0.00")
    ingresos_caja  = mov_caja.filter(tipo="ingreso").aggregate(
        total=Sum("monto"))["total"] or Decimal("0.00")
    egresos_caja   = mov_caja.filter(tipo="egreso").aggregate(
        total=Sum("monto"))["total"] or Decimal("0.00")

    total_ingresos = ingresos_banco + ingresos_caja
    total_egresos  = egresos_banco  + egresos_caja
    flujo_neto     = total_ingresos - total_egresos

    return render(request, "tesoreria/flujo_caja.html", {
        "inicio": inicio, "fin": fin,
        "mov_banco": mov_banco, "mov_caja": mov_caja,
        "ingresos_banco": ingresos_banco, "egresos_banco": egresos_banco,
        "ingresos_caja":  ingresos_caja,  "egresos_caja":  egresos_caja,
        "total_ingresos": total_ingresos, "total_egresos": total_egresos,
        "flujo_neto": flujo_neto,
    })
