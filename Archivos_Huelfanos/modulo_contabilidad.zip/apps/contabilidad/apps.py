from django.apps import AppConfig


class ContabilidadConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name               = "apps.contabilidad"
    verbose_name       = "Contabilidad — Plan de Cuentas, Asientos y Reportes"
