# apps/transportes/urls.py
from django.urls import path
from . import views

app_name = "transportes"

urlpatterns = [
    # Dashboard
    path("",                                                  views.dashboard_transportes,        name="dashboard"),

    # Vehículos
    path("vehiculos/",                                        views.vehiculo_list,                name="vehiculo_list"),
    path("vehiculos/nuevo/",                                  views.vehiculo_create,              name="vehiculo_create"),
    path("vehiculos/<int:pk>/",                               views.vehiculo_detail,              name="vehiculo_detail"),
    path("vehiculos/<int:pk>/editar/",                        views.vehiculo_edit,                name="vehiculo_edit"),

    # Conductores
    path("conductores/",                                      views.conductor_list,               name="conductor_list"),
    path("conductores/nuevo/",                                views.conductor_create,             name="conductor_create"),
    path("conductores/<int:pk>/",                             views.conductor_detail,             name="conductor_detail"),
    path("conductores/<int:pk>/editar/",                      views.conductor_edit,               name="conductor_edit"),

    # Rutas
    path("rutas/",                                            views.ruta_list,                    name="ruta_list"),
    path("rutas/nueva/",                                      views.ruta_create,                  name="ruta_create"),
    path("rutas/<int:pk>/",                                   views.ruta_detail,                  name="ruta_detail"),
    path("rutas/<int:pk>/editar/",                            views.ruta_edit,                    name="ruta_edit"),
    path("rutas/<int:pk>/punto/nuevo/",                       views.ruta_agregar_punto,           name="ruta_agregar_punto"),
    path("rutas/<int:pk>/punto/<int:ppk>/eliminar/",          views.ruta_eliminar_punto,          name="ruta_eliminar_punto"),

    # Despachos
    path("despachos/",                                        views.despacho_list,                name="despacho_list"),
    path("despachos/nuevo/",                                  views.despacho_create,              name="despacho_create"),
    path("despachos/<int:pk>/",                               views.despacho_detail,              name="despacho_detail"),
    path("despachos/<int:pk>/iniciar/",                       views.despacho_iniciar,             name="despacho_iniciar"),
    path("despachos/<int:pk>/finalizar/",                     views.despacho_finalizar,           name="despacho_finalizar"),
    path("despachos/<int:pk>/cancelar/",                      views.despacho_cancelar,            name="despacho_cancelar"),
    path("despachos/<int:pk>/entrega/<int:epk>/actualizar/",  views.despacho_actualizar_entrega,  name="despacho_actualizar_entrega"),

    # Mantenimiento
    path("mantenimientos/",                                   views.mantenimiento_list,           name="mantenimiento_list"),
    path("mantenimientos/nuevo/",                             views.mantenimiento_create,         name="mantenimiento_create"),
    path("mantenimientos/<int:pk>/completar/",                views.mantenimiento_completar,      name="mantenimiento_completar"),
]
