from django.apps import AppConfig


class TransportesConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name               = "apps.transportes"
    verbose_name       = "Transportes — Vehículos, Conductores y Rutas"
