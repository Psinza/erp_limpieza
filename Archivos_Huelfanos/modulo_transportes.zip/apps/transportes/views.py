# apps/transportes/views.py
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q, Sum, Count
from django.utils import timezone
from decimal import Decimal

from .models import (
    TipoVehiculo, Vehiculo, Conductor,
    Zona, Ruta, PuntoEntrega,
    Despacho, EntregaDespacho, Mantenimiento,
)
from .forms import (
    TipoVehiculoForm, VehiculoForm, ConductorForm,
    ZonaForm, RutaForm, PuntoEntregaForm,
    DespachoForm, DespachoFinalizarForm, EntregaDespachoForm,
    MantenimientoForm,
)


# ─────────────────────────────────────────────
#  DASHBOARD
# ─────────────────────────────────────────────
@login_required
def dashboard_transportes(request):
    from django.db.models import F
    hoy = timezone.now().date()

    total_vehiculos     = Vehiculo.objects.filter(estado="disponible").count()
    vehiculos_en_ruta   = Vehiculo.objects.filter(estado="en_ruta").count()
    conductores_activos = Conductor.objects.filter(estado="activo").count()
    despachos_hoy       = Despacho.objects.filter(
        fecha_salida__date=hoy
    ).exclude(estado="cancelado").count()

    despachos_activos   = Despacho.objects.filter(
        estado__in=["programado", "en_ruta"]
    ).select_related("ruta", "vehiculo", "conductor").order_by("fecha_salida")[:6]

    mantenimientos_pend = Mantenimiento.objects.filter(
        estado__in=["programado", "en_proceso"]
    ).select_related("vehiculo").order_by("fecha_programada")[:5]

    # Documentos por vencer (próximos 30 días)
    limite = timezone.now().date() + timezone.timedelta(days=30)
    docs_por_vencer = Vehiculo.objects.filter(
        Q(soat_vencimiento__lte=limite) |
        Q(revision_vencimiento__lte=limite) |
        Q(seguro_vencimiento__lte=limite),
        estado__in=["disponible", "en_ruta"]
    ).count()

    return render(request, "transportes/dashboard_transportes.html", {
        "total_vehiculos":     total_vehiculos,
        "vehiculos_en_ruta":   vehiculos_en_ruta,
        "conductores_activos": conductores_activos,
        "despachos_hoy":       despachos_hoy,
        "despachos_activos":   despachos_activos,
        "mantenimientos_pend": mantenimientos_pend,
        "docs_por_vencer":     docs_por_vencer,
    })


# ─────────────────────────────────────────────
#  VEHÍCULOS
# ─────────────────────────────────────────────
@login_required
def vehiculo_list(request):
    q      = request.GET.get("q", "")
    estado = request.GET.get("estado", "")
    qs     = Vehiculo.objects.select_related("tipo")
    if q:
        qs = qs.filter(
            Q(placa__icontains=q) |
            Q(marca__icontains=q) |
            Q(modelo__icontains=q)
        )
    if estado:
        qs = qs.filter(estado=estado)
    return render(request, "transportes/vehiculo_list.html", {
        "vehiculos": qs, "q": q, "estado": estado,
        "estados": Vehiculo.ESTADO_CHOICES,
    })


@login_required
def vehiculo_detail(request, pk):
    v             = get_object_or_404(Vehiculo, pk=pk)
    despachos     = v.despachos.order_by("-fecha_salida")[:10]
    mantenimientos= v.mantenimientos.order_by("-fecha_programada")[:5]
    return render(request, "transportes/vehiculo_detail.html", {
        "v": v, "despachos": despachos, "mantenimientos": mantenimientos,
    })


@login_required
def vehiculo_create(request):
    form = VehiculoForm(request.POST or None, request.FILES or None)
    if form.is_valid():
        form.save()
        messages.success(request, f"Vehículo '{form.instance.placa}' creado.")
        return redirect("transportes:vehiculo_detail", pk=form.instance.pk)
    return render(request, "transportes/vehiculo_form.html",
                  {"form": form, "titulo": "Nuevo Vehículo"})


@login_required
def vehiculo_edit(request, pk):
    v    = get_object_or_404(Vehiculo, pk=pk)
    form = VehiculoForm(request.POST or None, request.FILES or None, instance=v)
    if form.is_valid():
        form.save()
        messages.success(request, "Vehículo actualizado.")
        return redirect("transportes:vehiculo_detail", pk=pk)
    return render(request, "transportes/vehiculo_form.html",
                  {"form": form, "titulo": "Editar Vehículo", "v": v})


# ─────────────────────────────────────────────
#  CONDUCTORES
# ─────────────────────────────────────────────
@login_required
def conductor_list(request):
    q      = request.GET.get("q", "")
    estado = request.GET.get("estado", "")
    qs     = Conductor.objects.select_related("vehiculo_asignado")
    if q:
        qs = qs.filter(
            Q(nombres__icontains=q)   |
            Q(apellidos__icontains=q) |
            Q(cedula__icontains=q)
        )
    if estado:
        qs = qs.filter(estado=estado)
    return render(request, "transportes/conductor_list.html", {
        "conductores": qs, "q": q, "estado": estado,
        "estados": Conductor.ESTADO_CHOICES,
    })


@login_required
def conductor_detail(request, pk):
    c         = get_object_or_404(Conductor, pk=pk)
    despachos = c.despachos.select_related("ruta", "vehiculo").order_by("-fecha_salida")[:10]
    return render(request, "transportes/conductor_detail.html",
                  {"c": c, "despachos": despachos})


@login_required
def conductor_create(request):
    form = ConductorForm(request.POST or None, request.FILES or None)
    if form.is_valid():
        form.save()
        messages.success(request, f"Conductor '{form.instance.nombre_completo}' creado.")
        return redirect("transportes:conductor_detail", pk=form.instance.pk)
    return render(request, "transportes/conductor_form.html",
                  {"form": form, "titulo": "Nuevo Conductor"})


@login_required
def conductor_edit(request, pk):
    c    = get_object_or_404(Conductor, pk=pk)
    form = ConductorForm(request.POST or None, request.FILES or None, instance=c)
    if form.is_valid():
        form.save()
        messages.success(request, "Conductor actualizado.")
        return redirect("transportes:conductor_detail", pk=pk)
    return render(request, "transportes/conductor_form.html",
                  {"form": form, "titulo": "Editar Conductor", "c": c})


# ─────────────────────────────────────────────
#  RUTAS
# ─────────────────────────────────────────────
@login_required
def ruta_list(request):
    q   = request.GET.get("q", "")
    qs  = Ruta.objects.select_related("zona").annotate(num_puntos=Count("puntos"))
    if q:
        qs = qs.filter(
            Q(nombre__icontains=q)  |
            Q(codigo__icontains=q)  |
            Q(origen__icontains=q)  |
            Q(destino__icontains=q)
        )
    return render(request, "transportes/ruta_list.html", {"rutas": qs, "q": q})


@login_required
def ruta_detail(request, pk):
    ruta   = get_object_or_404(Ruta, pk=pk)
    puntos = ruta.puntos.filter(activo=True).order_by("orden")
    punto_form = PuntoEntregaForm()
    return render(request, "transportes/ruta_detail.html", {
        "ruta": ruta, "puntos": puntos, "punto_form": punto_form,
    })


@login_required
def ruta_create(request):
    form = RutaForm(request.POST or None)
    if form.is_valid():
        form.save()
        messages.success(request, f"Ruta '{form.instance.codigo}' creada.")
        return redirect("transportes:ruta_detail", pk=form.instance.pk)
    return render(request, "transportes/ruta_form.html",
                  {"form": form, "titulo": "Nueva Ruta"})


@login_required
def ruta_edit(request, pk):
    ruta = get_object_or_404(Ruta, pk=pk)
    form = RutaForm(request.POST or None, instance=ruta)
    if form.is_valid():
        form.save()
        messages.success(request, "Ruta actualizada.")
        return redirect("transportes:ruta_detail", pk=pk)
    return render(request, "transportes/ruta_form.html",
                  {"form": form, "titulo": "Editar Ruta", "ruta": ruta})


@login_required
def ruta_agregar_punto(request, pk):
    ruta = get_object_or_404(Ruta, pk=pk)
    form = PuntoEntregaForm(request.POST)
    if form.is_valid():
        punto      = form.save(commit=False)
        punto.ruta = ruta
        punto.save()
        messages.success(request, f"Punto '{punto.nombre}' agregado.")
    else:
        messages.error(request, f"Error: {form.errors}")
    return redirect("transportes:ruta_detail", pk=pk)


@login_required
def ruta_eliminar_punto(request, pk, ppk):
    punto = get_object_or_404(PuntoEntrega, pk=ppk, ruta__pk=pk)
    if request.method == "POST":
        punto.delete()
        messages.warning(request, "Punto eliminado.")
    return redirect("transportes:ruta_detail", pk=pk)


# ─────────────────────────────────────────────
#  DESPACHOS
# ─────────────────────────────────────────────
@login_required
def despacho_list(request):
    q      = request.GET.get("q", "")
    estado = request.GET.get("estado", "")
    qs     = Despacho.objects.select_related("ruta", "vehiculo", "conductor")
    if q:
        qs = qs.filter(
            Q(numero__icontains=q)            |
            Q(vehiculo__placa__icontains=q)    |
            Q(conductor__apellidos__icontains=q)
        )
    if estado:
        qs = qs.filter(estado=estado)
    return render(request, "transportes/despacho_list.html", {
        "despachos": qs, "q": q, "estado": estado,
        "estados": Despacho.ESTADO_CHOICES,
    })


@login_required
def despacho_create(request):
    form = DespachoForm(request.POST or None)
    if form.is_valid():
        d = form.save(commit=False)
        d.numero     = Despacho.generar_numero()
        d.creado_por = request.user
        d.save()
        # Marcar vehículo como ocupado
        vehiculo = d.vehiculo
        vehiculo.estado = "en_ruta"
        vehiculo.save()
        # Crear entregas para cada punto activo de la ruta
        for punto in d.ruta.puntos.filter(activo=True).order_by("orden"):
            EntregaDespacho.objects.create(despacho=d, punto_entrega=punto)
        messages.success(request, f"Despacho DSP-{d.numero} creado.")
        return redirect("transportes:despacho_detail", pk=d.pk)
    return render(request, "transportes/despacho_form.html",
                  {"form": form, "titulo": "Nuevo Despacho"})


@login_required
def despacho_detail(request, pk):
    d        = get_object_or_404(Despacho, pk=pk)
    entregas = d.entregas.select_related("punto_entrega").order_by("punto_entrega__orden")
    fin_form = DespachoFinalizarForm(instance=d)
    return render(request, "transportes/despacho_detail.html", {
        "d": d, "entregas": entregas, "fin_form": fin_form,
    })


@login_required
def despacho_iniciar(request, pk):
    d = get_object_or_404(Despacho, pk=pk)
    if d.estado == "programado":
        d.estado = "en_ruta"
        d.save()
        messages.success(request, f"Despacho DSP-{d.numero} iniciado.")
    return redirect("transportes:despacho_detail", pk=pk)


@login_required
def despacho_finalizar(request, pk):
    d = get_object_or_404(Despacho, pk=pk)
    if d.estado not in ["en_ruta", "con_novedad"]:
        messages.error(request, "El despacho debe estar En Ruta.")
        return redirect("transportes:despacho_detail", pk=pk)
    form = DespachoFinalizarForm(request.POST, instance=d)
    if form.is_valid():
        d = form.save(commit=False)
        d.km_recorridos = d.odometro_llegada - d.odometro_salida
        d.estado        = "con_novedad" if d.novedad else "completado"
        d.save()
        # Actualizar odómetro del vehículo
        d.vehiculo.odometro = d.odometro_llegada
        d.vehiculo.estado   = "disponible"
        d.vehiculo.save()
        messages.success(request, f"Despacho DSP-{d.numero} finalizado.")
    else:
        messages.error(request, f"Error: {form.errors}")
    return redirect("transportes:despacho_detail", pk=pk)


@login_required
def despacho_cancelar(request, pk):
    d = get_object_or_404(Despacho, pk=pk)
    if request.method == "POST" and d.estado in ["programado", "en_ruta"]:
        d.estado = "cancelado"
        d.save()
        d.vehiculo.estado = "disponible"
        d.vehiculo.save()
        messages.warning(request, f"Despacho DSP-{d.numero} cancelado.")
    return redirect("transportes:despacho_detail", pk=pk)


@login_required
def despacho_actualizar_entrega(request, pk, epk):
    d       = get_object_or_404(Despacho, pk=pk)
    entrega = get_object_or_404(EntregaDespacho, pk=epk, despacho=d)
    form    = EntregaDespachoForm(request.POST, instance=entrega)
    if form.is_valid():
        form.save()
        messages.success(request, f"Entrega en '{entrega.punto_entrega.nombre}' actualizada.")
    else:
        messages.error(request, f"Error: {form.errors}")
    return redirect("transportes:despacho_detail", pk=pk)


# ─────────────────────────────────────────────
#  MANTENIMIENTO
# ─────────────────────────────────────────────
@login_required
def mantenimiento_list(request):
    q      = request.GET.get("q", "")
    estado = request.GET.get("estado", "")
    qs     = Mantenimiento.objects.select_related("vehiculo")
    if q:
        qs = qs.filter(
            Q(vehiculo__placa__icontains=q) |
            Q(descripcion__icontains=q)
        )
    if estado:
        qs = qs.filter(estado=estado)
    return render(request, "transportes/mantenimiento_list.html", {
        "mantenimientos": qs, "q": q, "estado": estado,
        "estados": Mantenimiento.ESTADO_CHOICES,
    })


@login_required
def mantenimiento_create(request):
    form = MantenimientoForm(request.POST or None)
    if form.is_valid():
        m = form.save(commit=False)
        m.creado_por = request.user
        m.save()
        # Marcar vehículo en mantenimiento
        m.vehiculo.estado = "mantenimiento"
        m.vehiculo.save()
        messages.success(request, "Mantenimiento programado.")
        return redirect("transportes:mantenimiento_list")
    return render(request, "transportes/mantenimiento_form.html",
                  {"form": form, "titulo": "Programar Mantenimiento"})


@login_required
def mantenimiento_completar(request, pk):
    m = get_object_or_404(Mantenimiento, pk=pk)
    if request.method == "POST":
        if m.estado != "completado":
            m.estado         = "completado"
            m.fecha_ejecucion= timezone.now().date()
            m.save()
            m.vehiculo.estado = "disponible"
            m.vehiculo.save()
            messages.success(request, f"Mantenimiento completado. Vehículo {m.vehiculo.placa} disponible.")
        else:
            messages.error(request, "Ya estaba completado.")
    return redirect("transportes:mantenimiento_list")
