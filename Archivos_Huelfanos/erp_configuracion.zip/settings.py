# config/settings.py
# ============================================================
#  ERP FÁBRICA DE PRODUCTOS DE LIMPIEZA
#  Configuración Django 4.2+ con PostgreSQL
# ============================================================

import os
from pathlib import Path
from datetime import timedelta

# ──────────────────────────────────────────────
# RUTAS BASE
# ──────────────────────────────────────────────
BASE_DIR = Path(__file__).resolve().parent.parent


# ──────────────────────────────────────────────
# SEGURIDAD
# ──────────────────────────────────────────────
# IMPORTANTE: Cambiar en producción y nunca subir al repositorio.
# Generar con: python -c "from django.core.management.utils import get_random_secret_key; print(get_random_secret_key())"
SECRET_KEY = os.environ.get(
    "DJANGO_SECRET_KEY",
    "django-insecure-erp-limpieza-cambiar-en-produccion-2025"
)

# En producción: DEBUG = False
DEBUG = os.environ.get("DJANGO_DEBUG", "True") == "True"

ALLOWED_HOSTS = os.environ.get(
    "DJANGO_ALLOWED_HOSTS",
    "localhost 127.0.0.1 0.0.0.0"
).split()


# ──────────────────────────────────────────────
# APLICACIONES INSTALADAS
# ──────────────────────────────────────────────
INSTALLED_APPS = [
    # Django core
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",

    # Third-party
    "rest_framework",
    "rest_framework_simplejwt",
    "corsheaders",

    # ERP — Módulos de la fábrica de limpieza
    "apps.core",
    "apps.rrhh",
    "apps.compras",
    "apps.ventas",
    "apps.produccion",
    "apps.tesoreria",
    "apps.contabilidad",
    "apps.transportes",
]


# ──────────────────────────────────────────────
# MIDDLEWARE
# ──────────────────────────────────────────────
MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "whitenoise.middleware.WhiteNoiseMiddleware",        # servir estáticos en producción
    "django.contrib.sessions.middleware.SessionMiddleware",
    "corsheaders.middleware.CorsMiddleware",             # CORS (antes de CommonMiddleware)
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

ROOT_URLCONF = "config.urls"


# ──────────────────────────────────────────────
# TEMPLATES
# ──────────────────────────────────────────────
TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

WSGI_APPLICATION = "config.wsgi.application"


# ──────────────────────────────────────────────
# BASE DE DATOS — PostgreSQL
# ──────────────────────────────────────────────
DATABASES = {
    "default": {
        "ENGINE":   "django.db.backends.postgresql",
        "NAME":     os.environ.get("DB_NAME",     "erp_limpieza"),
        "USER":     os.environ.get("DB_USER",     "erp_user"),
        "PASSWORD": os.environ.get("DB_PASSWORD", "Erp$2025#Limpieza"),
        "HOST":     os.environ.get("DB_HOST",     "localhost"),
        "PORT":     os.environ.get("DB_PORT",     "5432"),
        "OPTIONS": {
            "options":          "-c default_transaction_isolation=read\ committed",
            "connect_timeout":  10,
        },
        "CONN_MAX_AGE": 60,           # mantener conexiones abiertas 60s
        "ATOMIC_REQUESTS": True,      # cada request en su propia transacción
    }
}

# Alternativa con URL de conexión (útil para PaaS como Heroku/Railway):
# DATABASE_URL = os.environ.get("DATABASE_URL")
# if DATABASE_URL:
#     import dj_database_url
#     DATABASES["default"] = dj_database_url.parse(DATABASE_URL, conn_max_age=60)


# ──────────────────────────────────────────────
# VALIDACIÓN DE CONTRASEÑAS
# ──────────────────────────────────────────────
AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator",
     "OPTIONS": {"min_length": 8}},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]

AUTH_USER_MODEL = "auth.User"   # se puede extender con core.Usuario si se desea


# ──────────────────────────────────────────────
# INTERNACIONALIZACIÓN
# ──────────────────────────────────────────────
LANGUAGE_CODE  = "es-ec"          # Español Ecuador
TIME_ZONE      = "America/Guayaquil"
USE_I18N       = True
USE_L10N       = True
USE_TZ         = True


# ──────────────────────────────────────────────
# ARCHIVOS ESTÁTICOS
# ──────────────────────────────────────────────
STATIC_URL  = "/static/"
STATIC_ROOT = BASE_DIR / "staticfiles"
STATICFILES_DIRS = [BASE_DIR / "static"]

# Whitenoise (compresión y caché de estáticos en producción)
STATICFILES_STORAGE = "whitenoise.storage.CompressedManifestStaticFilesStorage"


# ──────────────────────────────────────────────
# ARCHIVOS MULTIMEDIA (fotos de empleados, vehículos, etc.)
# ──────────────────────────────────────────────
MEDIA_URL  = "/media/"
MEDIA_ROOT = BASE_DIR / "media"


# ──────────────────────────────────────────────
# AUTO PRIMARY KEY
# ──────────────────────────────────────────────
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"


# ──────────────────────────────────────────────
# AUTENTICACIÓN Y SESIONES
# ──────────────────────────────────────────────
LOGIN_URL          = "/login/"
LOGIN_REDIRECT_URL = "/"
LOGOUT_REDIRECT_URL= "/login/"

SESSION_COOKIE_AGE            = 28800    # 8 horas en segundos
SESSION_EXPIRE_AT_BROWSER_CLOSE = False
SESSION_COOKIE_SECURE         = not DEBUG  # True en producción (HTTPS)
SESSION_COOKIE_HTTPONLY       = True
CSRF_COOKIE_SECURE            = not DEBUG
CSRF_COOKIE_HTTPONLY          = True


# ──────────────────────────────────────────────
# JWT (Django REST Framework + SimpleJWT)
# ──────────────────────────────────────────────
REST_FRAMEWORK = {
    "DEFAULT_AUTHENTICATION_CLASSES": [
        "rest_framework_simplejwt.authentication.JWTAuthentication",
        "rest_framework.authentication.SessionAuthentication",
    ],
    "DEFAULT_PERMISSION_CLASSES": [
        "rest_framework.permissions.IsAuthenticated",
    ],
    "DEFAULT_RENDERER_CLASSES": [
        "rest_framework.renderers.JSONRenderer",
    ],
    "DEFAULT_PAGINATION_CLASS": "rest_framework.pagination.PageNumberPagination",
    "PAGE_SIZE": 25,
}

SIMPLE_JWT = {
    "ACCESS_TOKEN_LIFETIME":  timedelta(hours=8),
    "REFRESH_TOKEN_LIFETIME": timedelta(days=7),
    "ROTATE_REFRESH_TOKENS":  True,
    "BLACKLIST_AFTER_ROTATION": True,
    "ALGORITHM":              "HS256",
    "SIGNING_KEY":            SECRET_KEY,
    "AUTH_HEADER_TYPES":      ("Bearer",),
    "USER_ID_FIELD":          "id",
    "USER_ID_CLAIM":          "user_id",
}


# ──────────────────────────────────────────────
# CORS (acceso desde frontend separado, ej: React/Vue)
# ──────────────────────────────────────────────
CORS_ALLOWED_ORIGINS = os.environ.get(
    "CORS_ALLOWED_ORIGINS",
    "http://localhost:3000 http://localhost:8080"
).split()

CORS_ALLOW_CREDENTIALS = True

CORS_ALLOW_HEADERS = [
    "accept", "accept-encoding", "authorization",
    "content-type", "dnt", "origin",
    "user-agent", "x-csrftoken", "x-requested-with",
]


# ──────────────────────────────────────────────
# CACHÉ (Redis en producción, LocMem en desarrollo)
# ──────────────────────────────────────────────
REDIS_URL = os.environ.get("REDIS_URL", "")

if REDIS_URL:
    CACHES = {
        "default": {
            "BACKEND":  "django.core.cache.backends.redis.RedisCache",
            "LOCATION": REDIS_URL,
            "OPTIONS":  {
                "CLIENT_CLASS": "django_redis.client.DefaultClient",
                "SOCKET_CONNECT_TIMEOUT": 5,
                "SOCKET_TIMEOUT": 5,
            },
        }
    }
else:
    CACHES = {
        "default": {
            "BACKEND": "django.core.cache.backends.locmem.LocMemCache",
            "LOCATION": "erp-limpieza-cache",
        }
    }

CACHE_MIDDLEWARE_SECONDS = 300


# ──────────────────────────────────────────────
# EMAIL (configuración para notificaciones)
# ──────────────────────────────────────────────
EMAIL_BACKEND = os.environ.get(
    "EMAIL_BACKEND",
    "django.core.mail.backends.console.EmailBackend"   # consola en desarrollo
)
EMAIL_HOST          = os.environ.get("EMAIL_HOST",     "smtp.gmail.com")
EMAIL_PORT          = int(os.environ.get("EMAIL_PORT", "587"))
EMAIL_USE_TLS       = os.environ.get("EMAIL_USE_TLS",  "True") == "True"
EMAIL_HOST_USER     = os.environ.get("EMAIL_HOST_USER",    "")
EMAIL_HOST_PASSWORD = os.environ.get("EMAIL_HOST_PASSWORD","")
DEFAULT_FROM_EMAIL  = os.environ.get("DEFAULT_FROM_EMAIL", "ERP Limpieza <no-reply@erp-limpieza.com>")
SERVER_EMAIL        = DEFAULT_FROM_EMAIL


# ──────────────────────────────────────────────
# LOGGING
# ──────────────────────────────────────────────
LOGGING = {
    "version":            1,
    "disable_existing_loggers": False,
    "formatters": {
        "verbose": {
            "format": "[{asctime}] {levelname} {name}: {message}",
            "style":  "{",
            "datefmt": "%Y-%m-%d %H:%M:%S",
        },
        "simple": {
            "format": "{levelname} {message}",
            "style":  "{",
        },
    },
    "handlers": {
        "console": {
            "class":     "logging.StreamHandler",
            "formatter": "simple",
        },
        "file": {
            "class":     "logging.handlers.RotatingFileHandler",
            "filename":  BASE_DIR / "logs" / "erp.log",
            "maxBytes":  10 * 1024 * 1024,   # 10 MB
            "backupCount": 5,
            "formatter": "verbose",
        },
    },
    "root": {
        "handlers": ["console"],
        "level": "WARNING",
    },
    "loggers": {
        "django": {
            "handlers": ["console", "file"],
            "level":    os.environ.get("DJANGO_LOG_LEVEL", "INFO"),
            "propagate": False,
        },
        "django.db.backends": {
            "handlers": ["console"],
            "level":    "WARNING",   # cambiar a DEBUG para ver SQL en desarrollo
            "propagate": False,
        },
        "apps": {
            "handlers": ["console", "file"],
            "level":    "DEBUG" if DEBUG else "INFO",
            "propagate": False,
        },
    },
}

# Crear directorio de logs si no existe
(BASE_DIR / "logs").mkdir(exist_ok=True)


# ──────────────────────────────────────────────
# SEGURIDAD ADICIONAL (solo en producción)
# ──────────────────────────────────────────────
if not DEBUG:
    SECURE_HSTS_SECONDS              = 31536000   # 1 año
    SECURE_HSTS_INCLUDE_SUBDOMAINS   = True
    SECURE_HSTS_PRELOAD              = True
    SECURE_SSL_REDIRECT              = True
    SECURE_BROWSER_XSS_FILTER        = True
    SECURE_CONTENT_TYPE_NOSNIFF      = True
    X_FRAME_OPTIONS                  = "DENY"
    SECURE_REFERRER_POLICY           = "strict-origin-when-cross-origin"


# ──────────────────────────────────────────────
# CONFIGURACIÓN DEL ADMIN DJANGO
# ──────────────────────────────────────────────
ADMIN_SITE_HEADER = "ERP — Fábrica de Productos de Limpieza"
ADMIN_SITE_TITLE  = "Panel Administrativo ERP"
ADMIN_INDEX_TITLE = "Gestión del Sistema"


# ──────────────────────────────────────────────
# CONFIGURACIONES PERSONALIZADAS DEL ERP
# ──────────────────────────────────────────────
ERP_CONFIG = {
    "EMPRESA_NOMBRE":   os.environ.get("EMPRESA_NOMBRE",   "Fábrica de Productos de Limpieza S.A."),
    "EMPRESA_RUC":      os.environ.get("EMPRESA_RUC",      "0990000001001"),
    "EMPRESA_CIUDAD":   os.environ.get("EMPRESA_CIUDAD",   "Guayaquil"),
    "EMPRESA_TELEFONO": os.environ.get("EMPRESA_TELEFONO", "04-2000000"),
    "EMPRESA_EMAIL":    os.environ.get("EMPRESA_EMAIL",    "info@erp-limpieza.com"),
    "MONEDA":           "USD",
    "DECIMALES":        2,
    "IVA_PORCENTAJE":   12.00,
    "MODULOS_ACTIVOS": [
        "core", "rrhh", "compras", "ventas",
        "produccion", "tesoreria", "contabilidad", "transportes",
    ],
}
