# config/urls.py
# ============================================================
#  ERP FÁBRICA DE PRODUCTOS DE LIMPIEZA
#  URLs principales — todos los módulos
# ============================================================

from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
    TokenVerifyView,
)

# Personalizar el admin
admin.site.site_header = settings.ADMIN_SITE_HEADER
admin.site.site_title  = settings.ADMIN_SITE_TITLE
admin.site.index_title = settings.ADMIN_INDEX_TITLE

urlpatterns = [
    # ── Panel de administración Django ──────────────────────
    path("admin/",            admin.site.urls),

    # ── Autenticación JWT ────────────────────────────────────
    path("api/token/",         TokenObtainPairView.as_view(),  name="token_obtain_pair"),
    path("api/token/refresh/", TokenRefreshView.as_view(),     name="token_refresh"),
    path("api/token/verify/",  TokenVerifyView.as_view(),      name="token_verify"),

    # ── Módulos ERP ──────────────────────────────────────────
    path("",               include("apps.core.urls",          namespace="core")),
    path("rrhh/",          include("apps.rrhh.urls",          namespace="rrhh")),
    path("compras/",       include("apps.compras.urls",        namespace="compras")),
    path("ventas/",        include("apps.ventas.urls",         namespace="ventas")),
    path("produccion/",    include("apps.produccion.urls",     namespace="produccion")),
    path("tesoreria/",     include("apps.tesoreria.urls",      namespace="tesoreria")),
    path("contabilidad/",  include("apps.contabilidad.urls",   namespace="contabilidad")),
    path("transportes/",   include("apps.transportes.urls",    namespace="transportes")),
]

# ── Servir archivos media en desarrollo ──────────────────────
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL,  document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)

    # Django Debug Toolbar (solo en desarrollo)
    try:
        import debug_toolbar
        urlpatterns = [
            path("__debug__/", include(debug_toolbar.urls)),
        ] + urlpatterns
    except ImportError:
        pass
