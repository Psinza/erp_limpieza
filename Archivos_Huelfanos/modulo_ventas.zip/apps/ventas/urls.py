# apps/ventas/urls.py
from django.urls import path
from . import views

app_name = "ventas"

urlpatterns = [
    # Dashboard
    path("",                                             views.dashboard_ventas,          name="dashboard"),

    # Categorías de cliente
    path("cat-clientes/",                                views.categoria_cliente_list,    name="categoria_cliente_list"),
    path("cat-clientes/nueva/",                          views.categoria_cliente_create,  name="categoria_cliente_create"),
    path("cat-clientes/<int:pk>/editar/",                views.categoria_cliente_edit,    name="categoria_cliente_edit"),

    # Clientes
    path("clientes/",                                    views.cliente_list,              name="cliente_list"),
    path("clientes/nuevo/",                              views.cliente_create,            name="cliente_create"),
    path("clientes/<int:pk>/",                           views.cliente_detail,            name="cliente_detail"),
    path("clientes/<int:pk>/editar/",                    views.cliente_edit,              name="cliente_edit"),
    path("clientes/<int:pk>/contacto/nuevo/",            views.cliente_contacto_add,      name="cliente_contacto_add"),
    path("clientes/<int:pk>/contacto/<int:cpk>/eliminar/",views.cliente_contacto_delete, name="cliente_contacto_delete"),

    # Productos de venta
    path("productos/",                                   views.producto_list,             name="producto_list"),
    path("productos/nuevo/",                             views.producto_create,           name="producto_create"),
    path("productos/<int:pk>/editar/",                   views.producto_edit,             name="producto_edit"),

    # Cotizaciones
    path("cotizaciones/",                                views.cotizacion_list,           name="cotizacion_list"),
    path("cotizaciones/nueva/",                          views.cotizacion_create,         name="cotizacion_create"),
    path("cotizaciones/<int:pk>/",                       views.cotizacion_detail,         name="cotizacion_detail"),
    path("cotizaciones/<int:pk>/editar/",                views.cotizacion_edit,           name="cotizacion_edit"),
    path("cotizaciones/<int:pk>/agregar-item/",          views.cotizacion_agregar_item,   name="cotizacion_agregar_item"),
    path("cotizaciones/<int:pk>/item/<int:dpk>/eliminar/",views.cotizacion_eliminar_item, name="cotizacion_eliminar_item"),
    path("cotizaciones/<int:pk>/enviar/",                views.cotizacion_enviar,         name="cotizacion_enviar"),
    path("cotizaciones/<int:pk>/aceptar/",               views.cotizacion_aceptar,        name="cotizacion_aceptar"),
    path("cotizaciones/<int:pk>/rechazar/",              views.cotizacion_rechazar,       name="cotizacion_rechazar"),
    path("cotizaciones/<int:pk>/convertir/",             views.cotizacion_convertir_pedido, name="cotizacion_convertir_pedido"),

    # Pedidos
    path("pedidos/",                                     views.pedido_list,               name="pedido_list"),
    path("pedidos/nuevo/",                               views.pedido_create,             name="pedido_create"),
    path("pedidos/<int:pk>/",                            views.pedido_detail,             name="pedido_detail"),
    path("pedidos/<int:pk>/editar/",                     views.pedido_edit,               name="pedido_edit"),
    path("pedidos/<int:pk>/agregar-item/",               views.pedido_agregar_item,       name="pedido_agregar_item"),
    path("pedidos/<int:pk>/item/<int:dpk>/eliminar/",    views.pedido_eliminar_item,      name="pedido_eliminar_item"),
    path("pedidos/<int:pk>/confirmar/",                  views.pedido_confirmar,          name="pedido_confirmar"),
    path("pedidos/<int:pk>/en-proceso/",                 views.pedido_en_proceso,         name="pedido_en_proceso"),
    path("pedidos/<int:pk>/anular/",                     views.pedido_anular,             name="pedido_anular"),

    # Despachos
    path("despachos/",                                   views.despacho_list,             name="despacho_list"),
    path("pedidos/<int:pedido_pk>/despacho/nuevo/",      views.despacho_create,           name="despacho_create"),
    path("despachos/<int:pk>/",                          views.despacho_detail,           name="despacho_detail"),
    path("despachos/<int:pk>/agregar/",                  views.despacho_agregar_item,     name="despacho_agregar_item"),
    path("despachos/<int:pk>/entregar/",                 views.despacho_entregar,         name="despacho_entregar"),
]
