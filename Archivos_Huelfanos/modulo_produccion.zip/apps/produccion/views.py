# apps/produccion/views.py
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q, Sum, Count
from django.utils import timezone
from decimal import Decimal

from .models import (
    CategoriaProductoTerminado, CategoriaMateriaPrima,
    ProductoTerminado, MateriaPrima,
    Formula, LineaFormula,
    OrdenProduccion, LoteProduccion,
    ConsumoMateriaPrima, ControlCalidad,
)
from .forms import (
    CategoriaProductoTerminadoForm, CategoriaMateriaPrimaForm,
    ProductoTerminadoForm, MateriaPrimaForm, AjusteStockMateriaPrimaForm,
    FormulaForm, LineaFormulaForm,
    OrdenProduccionForm, LoteProduccionForm,
    ConsumoMateriaPrimaForm, ControlCalidadForm,
)


# ─────────────────────────────────────────────
#  DASHBOARD
# ─────────────────────────────────────────────
@login_required
def dashboard_produccion(request):
    hoy = timezone.now().date()
    ordenes_activas   = OrdenProduccion.objects.filter(
        estado__in=["planificada", "en_proceso", "pausada"]
    ).count()
    lotes_control     = LoteProduccion.objects.filter(estado="control").count()
    stock_bajo_mp     = MateriaPrima.objects.filter(
        activo=True, stock_actual__lte=models_stock_minimo()
    ).count() if False else _contar_stock_bajo_mp()
    stock_bajo_pt     = _contar_stock_bajo_pt()

    ordenes_recientes = OrdenProduccion.objects.select_related(
        "formula__producto"
    ).order_by("-creado_en")[:6]
    lotes_recientes   = LoteProduccion.objects.select_related(
        "orden__formula__producto"
    ).order_by("-fecha_produccion")[:5]
    formulas_activas  = Formula.objects.filter(estado="activa").count()

    return render(request, "produccion/dashboard_produccion.html", {
        "ordenes_activas":  ordenes_activas,
        "lotes_control":    lotes_control,
        "stock_bajo_mp":    stock_bajo_mp,
        "stock_bajo_pt":    stock_bajo_pt,
        "ordenes_recientes":ordenes_recientes,
        "lotes_recientes":  lotes_recientes,
        "formulas_activas": formulas_activas,
    })


def _contar_stock_bajo_mp():
    from django.db.models import F
    return MateriaPrima.objects.filter(
        activo=True, stock_actual__lte=F("stock_minimo")
    ).count()


def _contar_stock_bajo_pt():
    from django.db.models import F
    return ProductoTerminado.objects.filter(
        activo=True, stock_actual__lte=F("stock_minimo")
    ).count()


# ─────────────────────────────────────────────
#  MATERIAS PRIMAS
# ─────────────────────────────────────────────
@login_required
def materia_prima_list(request):
    from django.db.models import F
    q       = request.GET.get("q", "")
    cat     = request.GET.get("categoria", "")
    alerta  = request.GET.get("alerta", "")

    qs = MateriaPrima.objects.select_related("categoria").filter(activo=True)
    if q:
        qs = qs.filter(Q(nombre__icontains=q) | Q(codigo__icontains=q))
    if cat:
        qs = qs.filter(categoria__id=cat)
    if alerta:
        qs = qs.filter(stock_actual__lte=F("stock_minimo"))

    categorias = CategoriaMateriaPrima.objects.all()
    return render(request, "produccion/materia_prima_list.html", {
        "materias": qs, "categorias": categorias,
        "q": q, "cat": cat, "alerta": alerta,
    })


@login_required
def materia_prima_create(request):
    form = MateriaPrimaForm(request.POST or None)
    if form.is_valid():
        form.save()
        messages.success(request, "Materia prima creada.")
        return redirect("produccion:materia_prima_list")
    return render(request, "produccion/materia_prima_form.html",
                  {"form": form, "titulo": "Nueva Materia Prima"})


@login_required
def materia_prima_edit(request, pk):
    obj  = get_object_or_404(MateriaPrima, pk=pk)
    form = MateriaPrimaForm(request.POST or None, instance=obj)
    if form.is_valid():
        form.save()
        messages.success(request, "Materia prima actualizada.")
        return redirect("produccion:materia_prima_list")
    return render(request, "produccion/materia_prima_form.html",
                  {"form": form, "titulo": "Editar Materia Prima"})


@login_required
def materia_prima_ajuste_stock(request, pk):
    mp   = get_object_or_404(MateriaPrima, pk=pk)
    form = AjusteStockMateriaPrimaForm(request.POST or None)
    if form.is_valid():
        cantidad = form.cleaned_data["cantidad"]
        motivo   = form.cleaned_data["motivo"]
        mp.stock_actual += cantidad
        mp.save()
        messages.success(
            request,
            f"Stock ajustado: {'+' if cantidad >= 0 else ''}{cantidad} {mp.unidad_medida}. "
            f"Nuevo stock: {mp.stock_actual}. Motivo: {motivo}"
        )
        return redirect("produccion:materia_prima_list")
    return render(request, "produccion/materia_prima_ajuste_stock.html",
                  {"form": form, "mp": mp})


# ─────────────────────────────────────────────
#  PRODUCTOS TERMINADOS
# ─────────────────────────────────────────────
@login_required
def producto_terminado_list(request):
    from django.db.models import F
    q      = request.GET.get("q", "")
    cat    = request.GET.get("categoria", "")
    alerta = request.GET.get("alerta", "")

    qs = ProductoTerminado.objects.select_related("categoria").filter(activo=True)
    if q:
        qs = qs.filter(Q(nombre__icontains=q) | Q(codigo__icontains=q))
    if cat:
        qs = qs.filter(categoria__id=cat)
    if alerta:
        qs = qs.filter(stock_actual__lte=F("stock_minimo"))

    categorias = CategoriaProductoTerminado.objects.all()
    return render(request, "produccion/producto_terminado_list.html", {
        "productos": qs, "categorias": categorias,
        "q": q, "cat": cat, "alerta": alerta,
    })


@login_required
def producto_terminado_create(request):
    form = ProductoTerminadoForm(request.POST or None)
    if form.is_valid():
        form.save()
        messages.success(request, "Producto terminado creado.")
        return redirect("produccion:producto_terminado_list")
    return render(request, "produccion/producto_terminado_form.html",
                  {"form": form, "titulo": "Nuevo Producto Terminado"})


@login_required
def producto_terminado_edit(request, pk):
    obj  = get_object_or_404(ProductoTerminado, pk=pk)
    form = ProductoTerminadoForm(request.POST or None, instance=obj)
    if form.is_valid():
        form.save()
        messages.success(request, "Producto actualizado.")
        return redirect("produccion:producto_terminado_list")
    return render(request, "produccion/producto_terminado_form.html",
                  {"form": form, "titulo": "Editar Producto Terminado"})


# ─────────────────────────────────────────────
#  FÓRMULAS
# ─────────────────────────────────────────────
@login_required
def formula_list(request):
    q      = request.GET.get("q", "")
    estado = request.GET.get("estado", "")
    qs     = Formula.objects.select_related("producto")
    if q:
        qs = qs.filter(Q(nombre__icontains=q) | Q(codigo__icontains=q)
                       | Q(producto__nombre__icontains=q))
    if estado:
        qs = qs.filter(estado=estado)
    return render(request, "produccion/formula_list.html", {
        "formulas": qs, "q": q, "estado": estado,
        "estados": Formula.ESTADO_CHOICES,
    })


@login_required
def formula_detail(request, pk):
    formula  = get_object_or_404(Formula, pk=pk)
    lineas   = formula.lineas.select_related("materia_prima").all()
    lin_form = LineaFormulaForm()
    return render(request, "produccion/formula_detail.html", {
        "formula": formula, "lineas": lineas, "lin_form": lin_form,
    })


@login_required
def formula_create(request):
    form = FormulaForm(request.POST or None)
    if form.is_valid():
        f = form.save(commit=False)
        f.creado_por = request.user
        f.save()
        messages.success(request, f"Fórmula {f.codigo} creada.")
        return redirect("produccion:formula_detail", pk=f.pk)
    return render(request, "produccion/formula_form.html",
                  {"form": form, "titulo": "Nueva Fórmula"})


@login_required
def formula_edit(request, pk):
    formula = get_object_or_404(Formula, pk=pk)
    form    = FormulaForm(request.POST or None, instance=formula)
    if form.is_valid():
        form.save()
        formula.calcular_costos()
        messages.success(request, "Fórmula actualizada.")
        return redirect("produccion:formula_detail", pk=pk)
    return render(request, "produccion/formula_form.html",
                  {"form": form, "titulo": "Editar Fórmula", "formula": formula})


@login_required
def formula_agregar_linea(request, pk):
    formula = get_object_or_404(Formula, pk=pk)
    form    = LineaFormulaForm(request.POST)
    if form.is_valid():
        linea         = form.save(commit=False)
        linea.formula = formula
        linea.save()
        formula.calcular_costos()
        messages.success(request, f"Ingrediente '{linea.materia_prima}' agregado.")
    else:
        messages.error(request, f"Error: {form.errors}")
    return redirect("produccion:formula_detail", pk=pk)


@login_required
def formula_eliminar_linea(request, pk, lpk):
    formula = get_object_or_404(Formula, pk=pk)
    linea   = get_object_or_404(LineaFormula, pk=lpk, formula=formula)
    if request.method == "POST":
        linea.delete()
        formula.calcular_costos()
        messages.warning(request, "Ingrediente eliminado.")
    return redirect("produccion:formula_detail", pk=pk)


@login_required
def formula_calcular_costos(request, pk):
    formula = get_object_or_404(Formula, pk=pk)
    formula.calcular_costos()
    messages.success(request,
        f"Costos recalculados: Costo MP = ${formula.costo_materia_prima} | "
        f"Costo unitario = ${formula.costo_unitario}")
    return redirect("produccion:formula_detail", pk=pk)


@login_required
def formula_activar(request, pk):
    formula = get_object_or_404(Formula, pk=pk)
    if formula.lineas.exists():
        formula.estado = "activa"
        formula.calcular_costos()
        messages.success(request, "Fórmula activada.")
    else:
        messages.error(request, "La fórmula debe tener al menos un ingrediente.")
    return redirect("produccion:formula_detail", pk=pk)


# ─────────────────────────────────────────────
#  ÓRDENES DE PRODUCCIÓN
# ─────────────────────────────────────────────
@login_required
def orden_list(request):
    q       = request.GET.get("q", "")
    estado  = request.GET.get("estado", "")
    qs      = OrdenProduccion.objects.select_related("formula__producto")
    if q:
        qs = qs.filter(
            Q(numero__icontains=q) |
            Q(formula__nombre__icontains=q) |
            Q(formula__producto__nombre__icontains=q)
        )
    if estado:
        qs = qs.filter(estado=estado)
    return render(request, "produccion/orden_list.html", {
        "ordenes": qs, "q": q, "estado": estado,
        "estados": OrdenProduccion.ESTADO_CHOICES,
    })


@login_required
def orden_create(request):
    form = OrdenProduccionForm(request.POST or None)
    if form.is_valid():
        orden = form.save(commit=False)
        orden.numero     = OrdenProduccion.generar_numero()
        orden.creado_por = request.user
        orden.save()
        orden.calcular_costo_estimado()
        messages.success(request, f"Orden OP-{orden.numero} creada.")
        return redirect("produccion:orden_detail", pk=orden.pk)
    return render(request, "produccion/orden_form.html",
                  {"form": form, "titulo": "Nueva Orden de Producción"})


@login_required
def orden_detail(request, pk):
    orden    = get_object_or_404(OrdenProduccion, pk=pk)
    lotes    = orden.lotes.order_by("-fecha_produccion")
    consumos = orden.consumos.select_related("materia_prima").all()
    lote_form    = LoteProduccionForm()
    consumo_form = ConsumoMateriaPrimaForm()
    return render(request, "produccion/orden_detail.html", {
        "orden": orden, "lotes": lotes, "consumos": consumos,
        "lote_form": lote_form, "consumo_form": consumo_form,
    })


@login_required
def orden_iniciar(request, pk):
    orden = get_object_or_404(OrdenProduccion, pk=pk)
    if orden.estado == "planificada":
        orden.estado      = "en_proceso"
        orden.fecha_inicio = timezone.now()
        orden.save()
        messages.success(request, f"Orden OP-{orden.numero} iniciada.")
    else:
        messages.error(request, "La orden debe estar en estado Planificada.")
    return redirect("produccion:orden_detail", pk=pk)


@login_required
def orden_pausar(request, pk):
    orden = get_object_or_404(OrdenProduccion, pk=pk)
    if orden.estado == "en_proceso":
        orden.estado = "pausada"
        orden.save()
        messages.warning(request, "Orden pausada.")
    return redirect("produccion:orden_detail", pk=pk)


@login_required
def orden_reanudar(request, pk):
    orden = get_object_or_404(OrdenProduccion, pk=pk)
    if orden.estado == "pausada":
        orden.estado = "en_proceso"
        orden.save()
        messages.success(request, "Orden reanudada.")
    return redirect("produccion:orden_detail", pk=pk)


@login_required
def orden_completar(request, pk):
    orden = get_object_or_404(OrdenProduccion, pk=pk)
    if orden.estado in ["en_proceso", "pausada"]:
        orden.estado    = "completada"
        orden.fecha_fin = timezone.now()
        # Calcular costo real
        costo_real = orden.consumos.aggregate(
            total=Sum("costo_total")
        )["total"] or Decimal("0.00")
        orden.costo_real = costo_real
        orden.save()
        messages.success(request, f"Orden OP-{orden.numero} completada.")
    else:
        messages.error(request, "La orden debe estar En Proceso o Pausada.")
    return redirect("produccion:orden_detail", pk=pk)


@login_required
def orden_anular(request, pk):
    orden = get_object_or_404(OrdenProduccion, pk=pk)
    if request.method == "POST":
        if orden.estado not in ["completada", "anulada"]:
            orden.estado = "anulada"
            orden.save()
            messages.warning(request, "Orden anulada.")
    return redirect("produccion:orden_detail", pk=pk)


@login_required
def orden_registrar_consumo(request, pk):
    orden = get_object_or_404(OrdenProduccion, pk=pk)
    if orden.estado != "en_proceso":
        messages.error(request, "Solo se puede registrar consumos en órdenes En Proceso.")
        return redirect("produccion:orden_detail", pk=pk)
    form = ConsumoMateriaPrimaForm(request.POST)
    if form.is_valid():
        consumo              = form.save(commit=False)
        consumo.orden        = orden
        consumo.registrado_por = request.user
        consumo.save()
        messages.success(request, f"Consumo de '{consumo.materia_prima}' registrado.")
    else:
        messages.error(request, f"Error: {form.errors}")
    return redirect("produccion:orden_detail", pk=pk)


# ─────────────────────────────────────────────
#  LOTES
# ─────────────────────────────────────────────
@login_required
def lote_create(request, orden_pk):
    orden = get_object_or_404(OrdenProduccion, pk=orden_pk)
    if orden.estado not in ["en_proceso", "completada"]:
        messages.error(request, "La orden debe estar En Proceso o Completada.")
        return redirect("produccion:orden_detail", pk=orden_pk)
    form = LoteProduccionForm(request.POST or None)
    if form.is_valid():
        lote               = form.save(commit=False)
        lote.orden         = orden
        lote.numero_lote   = LoteProduccion.generar_numero()
        lote.creado_por    = request.user
        lote.save()
        # Actualizar cantidad producida en la orden
        orden.cantidad_producida += lote.cantidad_producida / orden.formula.rendimiento
        orden.save()
        # Actualizar stock del producto terminado
        pt = orden.formula.producto
        pt.stock_actual += lote.cantidad_producida
        pt.save()
        messages.success(request, f"Lote {lote.numero_lote} creado.")
        return redirect("produccion:lote_detail", pk=lote.pk)
    return render(request, "produccion/lote_form.html",
                  {"form": form, "orden": orden})


@login_required
def lote_detail(request, pk):
    lote       = get_object_or_404(LoteProduccion, pk=pk)
    qc_form    = ControlCalidadForm()
    has_qc     = hasattr(lote, "control_calidad")
    return render(request, "produccion/lote_detail.html", {
        "lote": lote, "qc_form": qc_form, "has_qc": has_qc,
    })


@login_required
def lote_list(request):
    q      = request.GET.get("q", "")
    estado = request.GET.get("estado", "")
    qs     = LoteProduccion.objects.select_related(
        "orden__formula__producto"
    ).order_by("-fecha_produccion")
    if q:
        qs = qs.filter(
            Q(numero_lote__icontains=q) |
            Q(orden__formula__producto__nombre__icontains=q)
        )
    if estado:
        qs = qs.filter(estado=estado)
    return render(request, "produccion/lote_list.html", {
        "lotes": qs, "q": q, "estado": estado,
        "estados": LoteProduccion.ESTADO_CHOICES,
    })


@login_required
def lote_enviar_control(request, pk):
    lote = get_object_or_404(LoteProduccion, pk=pk)
    if lote.estado == "produccion":
        lote.estado = "control"
        lote.save()
        messages.info(request, f"Lote {lote.numero_lote} enviado a Control de Calidad.")
    return redirect("produccion:lote_detail", pk=pk)


@login_required
def lote_liberar(request, pk):
    lote = get_object_or_404(LoteProduccion, pk=pk)
    if lote.estado == "aprobado":
        lote.estado = "liberado"
        lote.save()
        messages.success(request, f"Lote {lote.numero_lote} liberado al almacén.")
    else:
        messages.error(request, "El lote debe estar Aprobado para liberarse.")
    return redirect("produccion:lote_detail", pk=pk)


# ─────────────────────────────────────────────
#  CONTROL DE CALIDAD
# ─────────────────────────────────────────────
@login_required
def control_calidad_create(request, lote_pk):
    lote = get_object_or_404(LoteProduccion, pk=lote_pk)
    if hasattr(lote, "control_calidad"):
        messages.warning(request, "Este lote ya tiene un control de calidad registrado.")
        return redirect("produccion:lote_detail", pk=lote_pk)
    form = ControlCalidadForm(request.POST or None)
    if form.is_valid():
        qc      = form.save(commit=False)
        qc.lote = lote
        qc.save()
        messages.success(request, f"Control de calidad registrado: {qc.get_resultado_display()}")
        return redirect("produccion:lote_detail", pk=lote_pk)
    return render(request, "produccion/control_calidad_form.html",
                  {"form": form, "lote": lote})
