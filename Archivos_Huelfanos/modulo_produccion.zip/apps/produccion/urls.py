# apps/produccion/urls.py
from django.urls import path
from . import views

app_name = "produccion"

urlpatterns = [
    # Dashboard
    path("",                                              views.dashboard_produccion,       name="dashboard"),

    # Materias Primas
    path("materias-primas/",                              views.materia_prima_list,          name="materia_prima_list"),
    path("materias-primas/nueva/",                        views.materia_prima_create,        name="materia_prima_create"),
    path("materias-primas/<int:pk>/editar/",              views.materia_prima_edit,          name="materia_prima_edit"),
    path("materias-primas/<int:pk>/ajuste-stock/",        views.materia_prima_ajuste_stock,  name="materia_prima_ajuste_stock"),

    # Productos Terminados
    path("productos-terminados/",                         views.producto_terminado_list,     name="producto_terminado_list"),
    path("productos-terminados/nuevo/",                   views.producto_terminado_create,   name="producto_terminado_create"),
    path("productos-terminados/<int:pk>/editar/",         views.producto_terminado_edit,     name="producto_terminado_edit"),

    # Fórmulas
    path("formulas/",                                     views.formula_list,                name="formula_list"),
    path("formulas/nueva/",                               views.formula_create,              name="formula_create"),
    path("formulas/<int:pk>/",                            views.formula_detail,              name="formula_detail"),
    path("formulas/<int:pk>/editar/",                     views.formula_edit,                name="formula_edit"),
    path("formulas/<int:pk>/agregar-linea/",              views.formula_agregar_linea,       name="formula_agregar_linea"),
    path("formulas/<int:pk>/linea/<int:lpk>/eliminar/",   views.formula_eliminar_linea,      name="formula_eliminar_linea"),
    path("formulas/<int:pk>/calcular-costos/",            views.formula_calcular_costos,     name="formula_calcular_costos"),
    path("formulas/<int:pk>/activar/",                    views.formula_activar,             name="formula_activar"),

    # Órdenes de Producción
    path("ordenes/",                                      views.orden_list,                  name="orden_list"),
    path("ordenes/nueva/",                                views.orden_create,                name="orden_create"),
    path("ordenes/<int:pk>/",                             views.orden_detail,                name="orden_detail"),
    path("ordenes/<int:pk>/iniciar/",                     views.orden_iniciar,               name="orden_iniciar"),
    path("ordenes/<int:pk>/pausar/",                      views.orden_pausar,                name="orden_pausar"),
    path("ordenes/<int:pk>/reanudar/",                    views.orden_reanudar,              name="orden_reanudar"),
    path("ordenes/<int:pk>/completar/",                   views.orden_completar,             name="orden_completar"),
    path("ordenes/<int:pk>/anular/",                      views.orden_anular,                name="orden_anular"),
    path("ordenes/<int:pk>/consumo/",                     views.orden_registrar_consumo,     name="orden_registrar_consumo"),

    # Lotes
    path("lotes/",                                        views.lote_list,                   name="lote_list"),
    path("ordenes/<int:orden_pk>/lotes/nuevo/",           views.lote_create,                 name="lote_create"),
    path("lotes/<int:pk>/",                               views.lote_detail,                 name="lote_detail"),
    path("lotes/<int:pk>/enviar-control/",                views.lote_enviar_control,         name="lote_enviar_control"),
    path("lotes/<int:pk>/liberar/",                       views.lote_liberar,                name="lote_liberar"),

    # Control de Calidad
    path("lotes/<int:lote_pk>/control-calidad/nuevo/",    views.control_calidad_create,      name="control_calidad_create"),
]
