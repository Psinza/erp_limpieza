# apps/produccion/forms.py
from django import forms
from .models import (
    CategoriaProductoTerminado, CategoriaMateriaPrima,
    ProductoTerminado, MateriaPrima,
    Formula, LineaFormula,
    OrdenProduccion, LoteProduccion,
    ConsumoMateriaPrima, ControlCalidad,
)

CTR  = {"class": "form-control"}
SEL  = {"class": "form-select"}
NUM  = {"class": "form-control", "step": "0.01"}
NUM4 = {"class": "form-control", "step": "0.0001"}
DATE = {"class": "form-control", "type": "date"}
DTTM = {"class": "form-control", "type": "datetime-local"}
CHK  = {"class": "form-check-input"}
TXT  = {"class": "form-control", "rows": 3}


class CategoriaProductoTerminadoForm(forms.ModelForm):
    class Meta:
        model   = CategoriaProductoTerminado
        fields  = ["nombre", "descripcion"]
        widgets = {"nombre": forms.TextInput(attrs=CTR),
                   "descripcion": forms.Textarea(attrs=TXT)}


class CategoriaMateriaPrimaForm(forms.ModelForm):
    class Meta:
        model   = CategoriaMateriaPrima
        fields  = ["nombre", "descripcion"]
        widgets = {"nombre": forms.TextInput(attrs=CTR),
                   "descripcion": forms.Textarea(attrs=TXT)}


class ProductoTerminadoForm(forms.ModelForm):
    class Meta:
        model  = ProductoTerminado
        fields = [
            "codigo", "nombre", "descripcion", "categoria",
            "unidad_medida", "stock_minimo", "activo",
        ]
        widgets = {
            "codigo":        forms.TextInput(attrs=CTR),
            "nombre":        forms.TextInput(attrs=CTR),
            "descripcion":   forms.Textarea(attrs=TXT),
            "categoria":     forms.Select(attrs=SEL),
            "unidad_medida": forms.Select(attrs=SEL),
            "stock_minimo":  forms.NumberInput(attrs=NUM),
            "activo":        forms.CheckboxInput(attrs=CHK),
        }


class MateriaPrimaForm(forms.ModelForm):
    class Meta:
        model  = MateriaPrima
        fields = [
            "codigo", "nombre", "descripcion", "categoria",
            "unidad_medida", "costo_unitario",
            "stock_minimo", "proveedor_ref", "activo",
        ]
        widgets = {
            "codigo":        forms.TextInput(attrs=CTR),
            "nombre":        forms.TextInput(attrs=CTR),
            "descripcion":   forms.Textarea(attrs=TXT),
            "categoria":     forms.Select(attrs=SEL),
            "unidad_medida": forms.Select(attrs=SEL),
            "costo_unitario":forms.NumberInput(attrs=NUM4),
            "stock_minimo":  forms.NumberInput(attrs=NUM),
            "proveedor_ref": forms.TextInput(attrs=CTR),
            "activo":        forms.CheckboxInput(attrs=CHK),
        }


class AjusteStockMateriaPrimaForm(forms.Form):
    """Formulario para ajustar el stock de una materia prima manualmente."""
    cantidad    = forms.DecimalField(
        max_digits=12, decimal_places=2,
        widget=forms.NumberInput(attrs={**NUM, "step": "0.01"}),
        help_text="Use valores negativos para reducir stock."
    )
    motivo      = forms.CharField(
        max_length=300,
        widget=forms.TextInput(attrs=CTR),
        help_text="Motivo del ajuste (compra, merma, inventario, etc.)"
    )


class FormulaForm(forms.ModelForm):
    class Meta:
        model  = Formula
        fields = [
            "codigo", "nombre", "producto", "version",
            "rendimiento", "unidad_rendimiento",
            "tiempo_produccion", "instrucciones", "estado",
        ]
        widgets = {
            "codigo":             forms.TextInput(attrs=CTR),
            "nombre":             forms.TextInput(attrs=CTR),
            "producto":           forms.Select(attrs=SEL),
            "version":            forms.TextInput(attrs=CTR),
            "rendimiento":        forms.NumberInput(attrs=NUM),
            "unidad_rendimiento": forms.TextInput(attrs=CTR),
            "tiempo_produccion":  forms.NumberInput(attrs=CTR),
            "instrucciones":      forms.Textarea(attrs={**TXT, "rows": 5}),
            "estado":             forms.Select(attrs=SEL),
        }


class LineaFormulaForm(forms.ModelForm):
    class Meta:
        model  = LineaFormula
        fields = ["materia_prima", "cantidad", "es_critica", "observacion"]
        widgets = {
            "materia_prima": forms.Select(attrs=SEL),
            "cantidad":      forms.NumberInput(attrs=NUM4),
            "es_critica":    forms.CheckboxInput(attrs=CHK),
            "observacion":   forms.TextInput(attrs=CTR),
        }


class OrdenProduccionForm(forms.ModelForm):
    class Meta:
        model  = OrdenProduccion
        fields = [
            "formula", "cantidad_planificada",
            "fecha_planificada", "prioridad",
            "responsable", "observaciones",
        ]
        widgets = {
            "formula":             forms.Select(attrs=SEL),
            "cantidad_planificada":forms.NumberInput(attrs=NUM),
            "fecha_planificada":   forms.DateInput(attrs=DATE),
            "prioridad":           forms.Select(attrs=SEL),
            "responsable":         forms.Select(attrs=SEL),
            "observaciones":       forms.Textarea(attrs=TXT),
        }


class LoteProduccionForm(forms.ModelForm):
    class Meta:
        model  = LoteProduccion
        fields = [
            "fecha_produccion", "fecha_vencimiento",
            "cantidad_producida", "observaciones",
        ]
        widgets = {
            "fecha_produccion":   forms.DateInput(attrs=DATE),
            "fecha_vencimiento":  forms.DateInput(attrs=DATE),
            "cantidad_producida": forms.NumberInput(attrs=NUM),
            "observaciones":      forms.Textarea(attrs=TXT),
        }


class ConsumoMateriaPrimaForm(forms.ModelForm):
    class Meta:
        model  = ConsumoMateriaPrima
        fields = ["materia_prima", "cantidad_planificada", "cantidad_real", "observacion"]
        widgets = {
            "materia_prima":       forms.Select(attrs=SEL),
            "cantidad_planificada":forms.NumberInput(attrs=NUM4),
            "cantidad_real":       forms.NumberInput(attrs=NUM4),
            "observacion":         forms.TextInput(attrs=CTR),
        }


class ControlCalidadForm(forms.ModelForm):
    class Meta:
        model  = ControlCalidad
        fields = [
            "fecha_inspeccion", "inspector",
            "ph", "viscosidad", "densidad",
            "color", "olor", "aspecto",
            "resultado", "observaciones", "acciones_correctivas",
        ]
        widgets = {
            "fecha_inspeccion":     forms.DateInput(attrs=DATE),
            "inspector":            forms.Select(attrs=SEL),
            "ph":                   forms.NumberInput(attrs={**NUM, "step": "0.01"}),
            "viscosidad":           forms.NumberInput(attrs={**NUM, "step": "0.01"}),
            "densidad":             forms.NumberInput(attrs={**NUM4, "step": "0.0001"}),
            "color":                forms.TextInput(attrs=CTR),
            "olor":                 forms.TextInput(attrs=CTR),
            "aspecto":              forms.TextInput(attrs=CTR),
            "resultado":            forms.Select(attrs=SEL),
            "observaciones":        forms.Textarea(attrs=TXT),
            "acciones_correctivas": forms.Textarea(attrs=TXT),
        }
