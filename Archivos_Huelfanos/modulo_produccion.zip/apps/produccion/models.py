# apps/produccion/models.py
from django.db import models
from django.contrib.auth import get_user_model
from django.core.validators import MinValueValidator
from decimal import Decimal

User = get_user_model()


# ─────────────────────────────────────────────
#  CATEGORÍAS
# ─────────────────────────────────────────────
class CategoriaProductoTerminado(models.Model):
    nombre      = models.CharField(max_length=100, unique=True)
    descripcion = models.TextField(blank=True)

    class Meta:
        verbose_name        = "Categoría de Producto Terminado"
        verbose_name_plural = "Categorías de Producto Terminado"
        ordering            = ["nombre"]

    def __str__(self):
        return self.nombre


class CategoriaMateriaPrima(models.Model):
    nombre      = models.CharField(max_length=100, unique=True)
    descripcion = models.TextField(blank=True)

    class Meta:
        verbose_name        = "Categoría de Materia Prima"
        verbose_name_plural = "Categorías de Materia Prima"
        ordering            = ["nombre"]

    def __str__(self):
        return self.nombre


# ─────────────────────────────────────────────
#  PRODUCTO TERMINADO
# ─────────────────────────────────────────────
class ProductoTerminado(models.Model):
    UNIDAD_CHOICES = [
        ("unidad",  "Unidad"),
        ("litro",   "Litro"),
        ("ml",      "Mililitro"),
        ("kg",      "Kilogramo"),
        ("g",       "Gramo"),
        ("caja",    "Caja"),
        ("paquete", "Paquete"),
        ("docena",  "Docena"),
    ]

    codigo          = models.CharField(max_length=50, unique=True)
    nombre          = models.CharField(max_length=200)
    descripcion     = models.TextField(blank=True)
    categoria       = models.ForeignKey(
        CategoriaProductoTerminado, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="productos"
    )
    unidad_medida   = models.CharField(max_length=20, choices=UNIDAD_CHOICES, default="unidad")
    costo_estimado  = models.DecimalField(
        max_digits=12, decimal_places=4, default=Decimal("0.0000"),
        help_text="Costo estimado por unidad (se actualiza al calcular)"
    )
    stock_actual    = models.DecimalField(
        max_digits=12, decimal_places=2, default=Decimal("0.00")
    )
    stock_minimo    = models.DecimalField(
        max_digits=12, decimal_places=2, default=Decimal("0.00")
    )
    activo          = models.BooleanField(default=True)
    creado_en       = models.DateTimeField(auto_now_add=True)
    modificado_en   = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name        = "Producto Terminado"
        verbose_name_plural = "Productos Terminados"
        ordering            = ["nombre"]

    def __str__(self):
        return f"[{self.codigo}] {self.nombre}"

    @property
    def stock_bajo(self):
        return self.stock_actual <= self.stock_minimo


# ─────────────────────────────────────────────
#  MATERIA PRIMA
# ─────────────────────────────────────────────
class MateriaPrima(models.Model):
    UNIDAD_CHOICES = [
        ("kg",      "Kilogramo"),
        ("g",       "Gramo"),
        ("litro",   "Litro"),
        ("ml",      "Mililitro"),
        ("unidad",  "Unidad"),
        ("rollo",   "Rollo"),
        ("metro",   "Metro"),
        ("caja",    "Caja"),
    ]

    codigo          = models.CharField(max_length=50, unique=True)
    nombre          = models.CharField(max_length=200)
    descripcion     = models.TextField(blank=True)
    categoria       = models.ForeignKey(
        CategoriaMateriaPrima, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="materias"
    )
    unidad_medida   = models.CharField(max_length=20, choices=UNIDAD_CHOICES, default="kg")
    costo_unitario  = models.DecimalField(
        max_digits=12, decimal_places=4, default=Decimal("0.0000")
    )
    stock_actual    = models.DecimalField(
        max_digits=12, decimal_places=2, default=Decimal("0.00")
    )
    stock_minimo    = models.DecimalField(
        max_digits=12, decimal_places=2, default=Decimal("0.00")
    )
    proveedor_ref   = models.CharField(
        max_length=200, blank=True,
        help_text="Proveedor principal de referencia"
    )
    activo          = models.BooleanField(default=True)
    creado_en       = models.DateTimeField(auto_now_add=True)
    modificado_en   = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name        = "Materia Prima"
        verbose_name_plural = "Materias Primas"
        ordering            = ["nombre"]

    def __str__(self):
        return f"[{self.codigo}] {self.nombre}"

    @property
    def stock_bajo(self):
        return self.stock_actual <= self.stock_minimo


# ─────────────────────────────────────────────
#  FÓRMULA / RECETA
# ─────────────────────────────────────────────
class Formula(models.Model):
    ESTADO_CHOICES = [
        ("borrador",  "Borrador"),
        ("activa",    "Activa"),
        ("obsoleta",  "Obsoleta"),
    ]

    codigo          = models.CharField(max_length=50, unique=True)
    nombre          = models.CharField(max_length=200)
    producto        = models.ForeignKey(
        ProductoTerminado, on_delete=models.PROTECT,
        related_name="formulas"
    )
    version         = models.CharField(max_length=10, default="1.0")
    rendimiento     = models.DecimalField(
        max_digits=12, decimal_places=2,
        validators=[MinValueValidator(Decimal("0.01"))],
        help_text="Cantidad producida por cada ejecución de esta fórmula"
    )
    unidad_rendimiento = models.CharField(max_length=20, default="unidad")
    tiempo_produccion  = models.PositiveIntegerField(
        default=0, help_text="Tiempo estimado en minutos"
    )
    instrucciones   = models.TextField(blank=True)
    estado          = models.CharField(max_length=10, choices=ESTADO_CHOICES, default="borrador")

    # Costos calculados
    costo_materia_prima = models.DecimalField(
        max_digits=14, decimal_places=4, default=Decimal("0.0000")
    )
    costo_unitario  = models.DecimalField(
        max_digits=14, decimal_places=4, default=Decimal("0.0000"),
        help_text="Costo por unidad producida"
    )

    creado_por      = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True,
        related_name="formulas_creadas"
    )
    creado_en       = models.DateTimeField(auto_now_add=True)
    modificado_en   = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name        = "Fórmula"
        verbose_name_plural = "Fórmulas"
        ordering            = ["producto", "version"]

    def __str__(self):
        return f"{self.codigo} — {self.nombre} v{self.version}"

    def calcular_costos(self):
        """Recalcula el costo total y unitario basado en las líneas de la fórmula."""
        total = Decimal("0.0000")
        for linea in self.lineas.all():
            total += linea.cantidad * linea.materia_prima.costo_unitario
        self.costo_materia_prima = total
        if self.rendimiento and self.rendimiento > 0:
            self.costo_unitario = total / self.rendimiento
        self.save()


class LineaFormula(models.Model):
    formula         = models.ForeignKey(
        Formula, on_delete=models.CASCADE, related_name="lineas"
    )
    materia_prima   = models.ForeignKey(
        MateriaPrima, on_delete=models.PROTECT, related_name="lineas_formula"
    )
    cantidad        = models.DecimalField(
        max_digits=12, decimal_places=4,
        validators=[MinValueValidator(Decimal("0.0001"))],
        help_text="Cantidad necesaria para producir el rendimiento indicado"
    )
    unidad          = models.CharField(max_length=20, blank=True,
                                       help_text="Se hereda de la materia prima si se deja vacío")
    es_critica      = models.BooleanField(
        default=False, help_text="Ingrediente crítico para la calidad"
    )
    observacion     = models.CharField(max_length=300, blank=True)

    class Meta:
        verbose_name        = "Línea de Fórmula"
        verbose_name_plural = "Líneas de Fórmula"
        unique_together     = ["formula", "materia_prima"]

    def __str__(self):
        return f"{self.formula} | {self.materia_prima}"

    def save(self, *args, **kwargs):
        if not self.unidad:
            self.unidad = self.materia_prima.unidad_medida
        super().save(*args, **kwargs)

    @property
    def costo_linea(self):
        return self.cantidad * self.materia_prima.costo_unitario


# ─────────────────────────────────────────────
#  ORDEN DE PRODUCCIÓN
# ─────────────────────────────────────────────
class OrdenProduccion(models.Model):
    ESTADO_CHOICES = [
        ("planificada", "Planificada"),
        ("en_proceso",  "En Proceso"),
        ("pausada",     "Pausada"),
        ("completada",  "Completada"),
        ("anulada",     "Anulada"),
    ]
    PRIORIDAD_CHOICES = [
        ("baja",   "Baja"),
        ("normal", "Normal"),
        ("alta",   "Alta"),
        ("urgente","Urgente"),
    ]

    numero          = models.CharField(max_length=20, unique=True)
    formula         = models.ForeignKey(
        Formula, on_delete=models.PROTECT, related_name="ordenes"
    )
    cantidad_planificada = models.DecimalField(
        max_digits=12, decimal_places=2,
        validators=[MinValueValidator(Decimal("0.01"))],
        help_text="Número de veces que se ejecuta la fórmula"
    )
    cantidad_producida = models.DecimalField(
        max_digits=12, decimal_places=2, default=Decimal("0.00")
    )

    fecha_planificada   = models.DateField()
    fecha_inicio        = models.DateTimeField(null=True, blank=True)
    fecha_fin           = models.DateTimeField(null=True, blank=True)

    estado          = models.CharField(max_length=12, choices=ESTADO_CHOICES, default="planificada")
    prioridad       = models.CharField(max_length=8,  choices=PRIORIDAD_CHOICES, default="normal")

    # Costos
    costo_estimado  = models.DecimalField(
        max_digits=14, decimal_places=2, default=Decimal("0.00")
    )
    costo_real      = models.DecimalField(
        max_digits=14, decimal_places=2, default=Decimal("0.00")
    )

    observaciones   = models.TextField(blank=True)
    notas_produccion= models.TextField(blank=True)

    # Auditoría
    creado_por      = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True,
        related_name="ordenes_produccion_creadas"
    )
    responsable     = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="ordenes_produccion_responsable"
    )
    creado_en       = models.DateTimeField(auto_now_add=True)
    modificado_en   = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name        = "Orden de Producción"
        verbose_name_plural = "Órdenes de Producción"
        ordering            = ["-fecha_planificada", "-numero"]

    def __str__(self):
        return f"OP-{self.numero} | {self.formula.producto.nombre}"

    def calcular_costo_estimado(self):
        self.costo_estimado = (
            self.formula.costo_materia_prima * self.cantidad_planificada
        )
        self.save()

    @property
    def unidades_planificadas(self):
        return self.cantidad_planificada * self.formula.rendimiento

    @property
    def unidades_producidas(self):
        return self.cantidad_producida * self.formula.rendimiento

    @classmethod
    def generar_numero(cls):
        from django.utils import timezone
        year  = timezone.now().year
        ultimo = cls.objects.filter(numero__startswith=str(year)).order_by("-numero").first()
        seq = 1
        if ultimo:
            try:
                seq = int(ultimo.numero.split("-")[-1]) + 1
            except (ValueError, IndexError):
                pass
        return f"{year}-{seq:04d}"


# ─────────────────────────────────────────────
#  LOTE DE PRODUCCIÓN
# ─────────────────────────────────────────────
class LoteProduccion(models.Model):
    ESTADO_CHOICES = [
        ("produccion", "En Producción"),
        ("control",    "En Control de Calidad"),
        ("aprobado",   "Aprobado"),
        ("rechazado",  "Rechazado"),
        ("liberado",   "Liberado a Almacén"),
    ]

    orden           = models.ForeignKey(
        OrdenProduccion, on_delete=models.CASCADE, related_name="lotes"
    )
    numero_lote     = models.CharField(max_length=50, unique=True)
    fecha_produccion= models.DateField()
    fecha_vencimiento = models.DateField(null=True, blank=True)

    cantidad_producida = models.DecimalField(
        max_digits=12, decimal_places=2,
        validators=[MinValueValidator(Decimal("0.01"))]
    )
    cantidad_aprobada  = models.DecimalField(
        max_digits=12, decimal_places=2, default=Decimal("0.00")
    )
    cantidad_rechazada = models.DecimalField(
        max_digits=12, decimal_places=2, default=Decimal("0.00")
    )

    estado          = models.CharField(max_length=12, choices=ESTADO_CHOICES, default="produccion")
    costo_real      = models.DecimalField(
        max_digits=14, decimal_places=2, default=Decimal("0.00")
    )
    observaciones   = models.TextField(blank=True)

    creado_por      = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True,
        related_name="lotes_creados"
    )
    creado_en       = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name        = "Lote de Producción"
        verbose_name_plural = "Lotes de Producción"
        ordering            = ["-fecha_produccion"]

    def __str__(self):
        return f"LOTE-{self.numero_lote} | {self.orden.formula.producto.nombre}"

    @classmethod
    def generar_numero(cls):
        from django.utils import timezone
        hoy = timezone.now()
        prefix = hoy.strftime("%Y%m%d")
        ultimo = cls.objects.filter(numero_lote__startswith=prefix).order_by("-numero_lote").first()
        seq = 1
        if ultimo:
            try:
                seq = int(ultimo.numero_lote.split("-")[-1]) + 1
            except (ValueError, IndexError):
                pass
        return f"{prefix}-{seq:03d}"


# ─────────────────────────────────────────────
#  CONSUMO DE MATERIA PRIMA
# ─────────────────────────────────────────────
class ConsumoMateriaPrima(models.Model):
    orden           = models.ForeignKey(
        OrdenProduccion, on_delete=models.CASCADE, related_name="consumos"
    )
    lote            = models.ForeignKey(
        LoteProduccion, on_delete=models.CASCADE,
        null=True, blank=True, related_name="consumos"
    )
    materia_prima   = models.ForeignKey(
        MateriaPrima, on_delete=models.PROTECT, related_name="consumos"
    )
    cantidad_planificada = models.DecimalField(
        max_digits=12, decimal_places=4, default=Decimal("0.0000")
    )
    cantidad_real   = models.DecimalField(
        max_digits=12, decimal_places=4,
        validators=[MinValueValidator(Decimal("0.0001"))]
    )
    costo_unitario  = models.DecimalField(
        max_digits=12, decimal_places=4, default=Decimal("0.0000")
    )
    costo_total     = models.DecimalField(
        max_digits=14, decimal_places=2, default=Decimal("0.00")
    )
    observacion     = models.CharField(max_length=300, blank=True)
    registrado_por  = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True,
        related_name="consumos_registrados"
    )
    fecha_registro  = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name        = "Consumo de Materia Prima"
        verbose_name_plural = "Consumos de Materia Prima"

    def __str__(self):
        return f"OP-{self.orden.numero} | {self.materia_prima}"

    def save(self, *args, **kwargs):
        self.costo_unitario = self.materia_prima.costo_unitario
        self.costo_total    = self.cantidad_real * self.costo_unitario
        # Descontar del stock
        if not self.pk:  # Solo al crear
            mp = self.materia_prima
            mp.stock_actual -= self.cantidad_real
            mp.save()
        super().save(*args, **kwargs)


# ─────────────────────────────────────────────
#  CONTROL DE CALIDAD
# ─────────────────────────────────────────────
class ControlCalidad(models.Model):
    RESULTADO_CHOICES = [
        ("aprobado",  "Aprobado"),
        ("rechazado", "Rechazado"),
        ("condicional","Aprobado Condicionalmente"),
    ]

    lote            = models.OneToOneField(
        LoteProduccion, on_delete=models.CASCADE,
        related_name="control_calidad"
    )
    fecha_inspeccion= models.DateField()
    inspector       = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True,
        related_name="inspecciones"
    )

    # Parámetros de calidad (adaptable a productos de limpieza)
    ph              = models.DecimalField(
        max_digits=5, decimal_places=2, null=True, blank=True,
        verbose_name="pH"
    )
    viscosidad      = models.DecimalField(
        max_digits=8, decimal_places=2, null=True, blank=True,
        verbose_name="Viscosidad (cP)"
    )
    densidad        = models.DecimalField(
        max_digits=8, decimal_places=4, null=True, blank=True,
        verbose_name="Densidad (g/mL)"
    )
    color           = models.CharField(max_length=100, blank=True)
    olor            = models.CharField(max_length=100, blank=True)
    aspecto         = models.CharField(max_length=200, blank=True)

    # Resultado
    resultado       = models.CharField(
        max_length=12, choices=RESULTADO_CHOICES, default="aprobado"
    )
    observaciones   = models.TextField(blank=True)
    acciones_correctivas = models.TextField(blank=True)

    creado_en       = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name        = "Control de Calidad"
        verbose_name_plural = "Controles de Calidad"

    def __str__(self):
        return f"QC — {self.lote} | {self.get_resultado_display()}"

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        # Actualizar estado del lote según resultado
        if self.resultado == "aprobado" or self.resultado == "condicional":
            self.lote.estado            = "aprobado"
            self.lote.cantidad_aprobada = self.lote.cantidad_producida
        else:
            self.lote.estado             = "rechazado"
            self.lote.cantidad_rechazada = self.lote.cantidad_producida
        self.lote.save()
