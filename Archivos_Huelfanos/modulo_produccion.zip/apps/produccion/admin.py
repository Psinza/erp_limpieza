# apps/produccion/admin.py
from django.contrib import admin
from .models import (
    CategoriaProductoTerminado, CategoriaMateriaPrima,
    ProductoTerminado, MateriaPrima,
    Formula, LineaFormula,
    OrdenProduccion, LoteProduccion,
    ConsumoMateriaPrima, ControlCalidad,
)


@admin.register(CategoriaProductoTerminado)
class CatPTAdmin(admin.ModelAdmin):
    list_display  = ["nombre"]
    search_fields = ["nombre"]


@admin.register(CategoriaMateriaPrima)
class CatMPAdmin(admin.ModelAdmin):
    list_display  = ["nombre"]
    search_fields = ["nombre"]


@admin.register(ProductoTerminado)
class ProductoTerminadoAdmin(admin.ModelAdmin):
    list_display  = ["codigo", "nombre", "categoria", "unidad_medida",
                     "stock_actual", "stock_minimo", "costo_estimado", "activo"]
    list_filter   = ["categoria", "activo"]
    search_fields = ["codigo", "nombre"]


@admin.register(MateriaPrima)
class MateriaPrimaAdmin(admin.ModelAdmin):
    list_display  = ["codigo", "nombre", "categoria", "unidad_medida",
                     "costo_unitario", "stock_actual", "stock_minimo", "activo"]
    list_filter   = ["categoria", "activo"]
    search_fields = ["codigo", "nombre"]


class LineaFormulaInline(admin.TabularInline):
    model  = LineaFormula
    extra  = 1
    fields = ["materia_prima", "cantidad", "unidad", "es_critica", "observacion"]


@admin.register(Formula)
class FormulaAdmin(admin.ModelAdmin):
    list_display    = ["codigo", "nombre", "producto", "version",
                       "rendimiento", "costo_unitario", "estado"]
    list_filter     = ["estado", "producto"]
    search_fields   = ["codigo", "nombre"]
    readonly_fields = ["costo_materia_prima", "costo_unitario", "creado_en", "modificado_en"]
    inlines         = [LineaFormulaInline]


class ConsumoInline(admin.TabularInline):
    model           = ConsumoMateriaPrima
    extra           = 0
    fields          = ["materia_prima", "cantidad_planificada", "cantidad_real", "costo_total"]
    readonly_fields = ["costo_total"]


class LoteInline(admin.TabularInline):
    model  = LoteProduccion
    extra  = 0
    fields = ["numero_lote", "fecha_produccion", "cantidad_producida", "estado"]


@admin.register(OrdenProduccion)
class OrdenProduccionAdmin(admin.ModelAdmin):
    list_display    = ["numero", "formula", "cantidad_planificada",
                       "estado", "prioridad", "fecha_planificada", "costo_estimado"]
    list_filter     = ["estado", "prioridad"]
    search_fields   = ["numero", "formula__nombre"]
    readonly_fields = ["numero", "costo_estimado", "costo_real",
                       "creado_en", "modificado_en"]
    inlines         = [LoteInline, ConsumoInline]


@admin.register(LoteProduccion)
class LoteProduccionAdmin(admin.ModelAdmin):
    list_display = ["numero_lote", "orden", "fecha_produccion",
                    "cantidad_producida", "estado"]
    list_filter  = ["estado"]
    search_fields= ["numero_lote"]


@admin.register(ControlCalidad)
class ControlCalidadAdmin(admin.ModelAdmin):
    list_display = ["lote", "fecha_inspeccion", "inspector",
                    "resultado", "ph", "viscosidad"]
    list_filter  = ["resultado"]
