# apps/compras/admin.py
from django.contrib import admin
from .models import (
    CategoriaProveedor, Proveedor, ContactoProveedor,
    CategoriaProductoCompra, ProductoCompra,
    OrdenCompra, DetalleOrdenCompra,
    RecepcionCompra, DetalleRecepcion,
)


@admin.register(CategoriaProveedor)
class CategoriaProveedorAdmin(admin.ModelAdmin):
    list_display  = ["nombre"]
    search_fields = ["nombre"]


class ContactoInline(admin.TabularInline):
    model  = ContactoProveedor
    extra  = 1
    fields = ["nombre", "cargo", "telefono", "email", "principal"]


@admin.register(Proveedor)
class ProveedorAdmin(admin.ModelAdmin):
    list_display   = ["ruc", "razon_social", "categoria", "telefono", "estado", "creado_en"]
    list_filter    = ["estado", "tipo", "categoria"]
    search_fields  = ["ruc", "razon_social", "nombre_comercial"]
    readonly_fields= ["creado_en", "modificado_en"]
    inlines        = [ContactoInline]


@admin.register(CategoriaProductoCompra)
class CategoriaProductoAdmin(admin.ModelAdmin):
    list_display  = ["nombre"]
    search_fields = ["nombre"]


@admin.register(ProductoCompra)
class ProductoCompraAdmin(admin.ModelAdmin):
    list_display  = ["codigo", "nombre", "categoria", "unidad_medida", "precio_referencia", "activo"]
    list_filter   = ["categoria", "activo", "unidad_medida"]
    search_fields = ["codigo", "nombre"]


class DetalleOrdenInline(admin.TabularInline):
    model           = DetalleOrdenCompra
    extra           = 0
    fields          = ["producto", "cantidad", "precio_unitario", "descuento_pct", "subtotal"]
    readonly_fields = ["subtotal", "descuento_monto"]


@admin.register(OrdenCompra)
class OrdenCompraAdmin(admin.ModelAdmin):
    list_display    = ["numero", "proveedor", "fecha_emision", "estado", "total"]
    list_filter     = ["estado"]
    search_fields   = ["numero", "proveedor__razon_social"]
    readonly_fields = ["numero", "subtotal", "descuento_total",
                       "base_imponible", "impuesto_total", "total",
                       "creado_en", "modificado_en"]
    inlines         = [DetalleOrdenInline]


class DetalleRecepcionInline(admin.TabularInline):
    model  = DetalleRecepcion
    extra  = 0
    fields = ["detalle_orden", "cantidad_recibida", "cantidad_aceptada", "cantidad_rechazada"]


@admin.register(RecepcionCompra)
class RecepcionCompraAdmin(admin.ModelAdmin):
    list_display = ["numero", "orden", "fecha_recepcion", "estado", "recibido_por"]
    list_filter  = ["estado"]
    inlines      = [DetalleRecepcionInline]
