# apps/compras/models.py
from django.db import models
from django.contrib.auth import get_user_model
from django.core.validators import MinValueValidator
from decimal import Decimal

User = get_user_model()


# ─────────────────────────────────────────────
#  PROVEEDOR
# ─────────────────────────────────────────────
class CategoriaProveedor(models.Model):
    nombre      = models.CharField(max_length=100, unique=True)
    descripcion = models.TextField(blank=True)

    class Meta:
        verbose_name        = "Categoría de Proveedor"
        verbose_name_plural = "Categorías de Proveedor"
        ordering            = ["nombre"]

    def __str__(self):
        return self.nombre


class Proveedor(models.Model):
    TIPO_CHOICES = [
        ("persona_natural", "Persona Natural"),
        ("empresa",         "Empresa"),
    ]
    ESTADO_CHOICES = [
        ("activo",   "Activo"),
        ("inactivo", "Inactivo"),
        ("bloqueado","Bloqueado"),
    ]

    # Identificación
    ruc             = models.CharField(max_length=20, unique=True, verbose_name="RUC / NIT")
    razon_social    = models.CharField(max_length=200, verbose_name="Razón Social / Nombre")
    nombre_comercial= models.CharField(max_length=200, blank=True)
    tipo            = models.CharField(max_length=20, choices=TIPO_CHOICES, default="empresa")
    categoria       = models.ForeignKey(
        CategoriaProveedor, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="proveedores"
    )

    # Contacto
    telefono        = models.CharField(max_length=30, blank=True)
    telefono2       = models.CharField(max_length=30, blank=True)
    email           = models.EmailField(blank=True)
    sitio_web       = models.URLField(blank=True)
    direccion       = models.TextField(blank=True)
    ciudad          = models.CharField(max_length=100, blank=True)
    pais            = models.CharField(max_length=100, default="Ecuador")

    # Condiciones comerciales
    dias_credito    = models.PositiveIntegerField(default=0, help_text="Días de crédito otorgados")
    descuento_pct   = models.DecimalField(
        max_digits=5, decimal_places=2, default=Decimal("0.00"),
        verbose_name="Descuento %"
    )
    cuenta_bancaria = models.CharField(max_length=30, blank=True)
    banco           = models.CharField(max_length=100, blank=True)
    observaciones   = models.TextField(blank=True)

    estado          = models.CharField(max_length=10, choices=ESTADO_CHOICES, default="activo")

    # Auditoría
    creado_por      = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, related_name="proveedores_creados"
    )
    creado_en       = models.DateTimeField(auto_now_add=True)
    modificado_en   = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name        = "Proveedor"
        verbose_name_plural = "Proveedores"
        ordering            = ["razon_social"]

    def __str__(self):
        return f"{self.razon_social} [{self.ruc}]"

    @property
    def nombre_display(self):
        return self.nombre_comercial or self.razon_social


class ContactoProveedor(models.Model):
    proveedor   = models.ForeignKey(
        Proveedor, on_delete=models.CASCADE, related_name="contactos"
    )
    nombre      = models.CharField(max_length=150)
    cargo       = models.CharField(max_length=100, blank=True)
    telefono    = models.CharField(max_length=30, blank=True)
    email       = models.EmailField(blank=True)
    principal   = models.BooleanField(default=False)

    class Meta:
        verbose_name        = "Contacto de Proveedor"
        verbose_name_plural = "Contactos de Proveedor"

    def __str__(self):
        return f"{self.nombre} ({self.proveedor})"


# ─────────────────────────────────────────────
#  PRODUCTO DE COMPRA
# ─────────────────────────────────────────────
class CategoriaProductoCompra(models.Model):
    nombre      = models.CharField(max_length=100, unique=True)
    descripcion = models.TextField(blank=True)

    class Meta:
        verbose_name        = "Categoría de Producto"
        verbose_name_plural = "Categorías de Producto"
        ordering            = ["nombre"]

    def __str__(self):
        return self.nombre


class ProductoCompra(models.Model):
    UNIDAD_CHOICES = [
        ("unidad",    "Unidad"),
        ("kg",        "Kilogramo"),
        ("g",         "Gramo"),
        ("litro",     "Litro"),
        ("ml",        "Mililitro"),
        ("caja",      "Caja"),
        ("paquete",   "Paquete"),
        ("rollo",     "Rollo"),
        ("metro",     "Metro"),
        ("docena",    "Docena"),
    ]

    codigo          = models.CharField(max_length=50, unique=True)
    nombre          = models.CharField(max_length=200)
    descripcion     = models.TextField(blank=True)
    categoria       = models.ForeignKey(
        CategoriaProductoCompra, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="productos"
    )
    unidad_medida   = models.CharField(max_length=20, choices=UNIDAD_CHOICES, default="unidad")
    precio_referencia = models.DecimalField(
        max_digits=12, decimal_places=4, default=Decimal("0.0000"),
        help_text="Precio de referencia para órdenes"
    )
    stock_minimo    = models.DecimalField(
        max_digits=12, decimal_places=2, default=Decimal("0.00")
    )
    activo          = models.BooleanField(default=True)
    creado_en       = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name        = "Producto de Compra"
        verbose_name_plural = "Productos de Compra"
        ordering            = ["nombre"]

    def __str__(self):
        return f"[{self.codigo}] {self.nombre}"


# ─────────────────────────────────────────────
#  ORDEN DE COMPRA
# ─────────────────────────────────────────────
class OrdenCompra(models.Model):
    ESTADO_CHOICES = [
        ("borrador",   "Borrador"),
        ("enviada",    "Enviada al Proveedor"),
        ("confirmada", "Confirmada"),
        ("recibida",   "Recibida Parcialmente"),
        ("completada", "Completada"),
        ("anulada",    "Anulada"),
    ]

    numero          = models.CharField(max_length=20, unique=True, verbose_name="N° Orden")
    proveedor       = models.ForeignKey(
        Proveedor, on_delete=models.PROTECT, related_name="ordenes"
    )
    fecha_emision   = models.DateField()
    fecha_entrega   = models.DateField(null=True, blank=True, verbose_name="Fecha Entrega Esperada")
    estado          = models.CharField(max_length=15, choices=ESTADO_CHOICES, default="borrador")

    # Condiciones
    dias_credito    = models.PositiveIntegerField(default=0)
    descuento_pct   = models.DecimalField(max_digits=5, decimal_places=2, default=Decimal("0.00"))
    impuesto_pct    = models.DecimalField(
        max_digits=5, decimal_places=2, default=Decimal("12.00"),
        verbose_name="IVA %"
    )

    # Montos calculados
    subtotal        = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal("0.00"))
    descuento_total = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal("0.00"))
    base_imponible  = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal("0.00"))
    impuesto_total  = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal("0.00"))
    total           = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal("0.00"))

    notas           = models.TextField(blank=True)
    terminos        = models.TextField(blank=True, verbose_name="Términos y condiciones")

    # Auditoría
    creado_por      = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, related_name="ordenes_creadas"
    )
    aprobado_por    = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="ordenes_aprobadas"
    )
    creado_en       = models.DateTimeField(auto_now_add=True)
    modificado_en   = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name        = "Orden de Compra"
        verbose_name_plural = "Órdenes de Compra"
        ordering            = ["-fecha_emision", "-numero"]

    def __str__(self):
        return f"OC-{self.numero} | {self.proveedor.nombre_display} | {self.get_estado_display()}"

    def calcular_totales(self):
        detalles            = self.detalles.all()
        self.subtotal       = sum(d.subtotal       for d in detalles)
        self.descuento_total= sum(d.descuento_monto for d in detalles)
        self.base_imponible = self.subtotal - self.descuento_total
        self.impuesto_total = self.base_imponible * (self.impuesto_pct / Decimal("100"))
        self.total          = self.base_imponible + self.impuesto_total
        self.save()

    @classmethod
    def generar_numero(cls):
        from django.utils import timezone
        year  = timezone.now().year
        ultimo = cls.objects.filter(numero__startswith=str(year)).order_by("-numero").first()
        if ultimo:
            try:
                seq = int(ultimo.numero.split("-")[-1]) + 1
            except (ValueError, IndexError):
                seq = 1
        else:
            seq = 1
        return f"{year}-{seq:04d}"


class DetalleOrdenCompra(models.Model):
    orden           = models.ForeignKey(
        OrdenCompra, on_delete=models.CASCADE, related_name="detalles"
    )
    producto        = models.ForeignKey(
        ProductoCompra, on_delete=models.PROTECT, related_name="detalles_orden"
    )
    descripcion     = models.CharField(max_length=300, blank=True,
                                       help_text="Descripción adicional o personalizada")
    cantidad        = models.DecimalField(
        max_digits=12, decimal_places=2,
        validators=[MinValueValidator(Decimal("0.01"))]
    )
    precio_unitario = models.DecimalField(
        max_digits=12, decimal_places=4,
        validators=[MinValueValidator(Decimal("0.0001"))]
    )
    descuento_pct   = models.DecimalField(max_digits=5, decimal_places=2, default=Decimal("0.00"))
    descuento_monto = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal("0.00"))
    subtotal        = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal("0.00"))

    cantidad_recibida = models.DecimalField(
        max_digits=12, decimal_places=2, default=Decimal("0.00")
    )

    class Meta:
        verbose_name        = "Detalle de Orden de Compra"
        verbose_name_plural = "Detalles de Orden de Compra"

    def __str__(self):
        return f"{self.orden} | {self.producto}"

    def save(self, *args, **kwargs):
        self.descuento_monto = self.cantidad * self.precio_unitario * (
            self.descuento_pct / Decimal("100")
        )
        self.subtotal = (self.cantidad * self.precio_unitario) - self.descuento_monto
        super().save(*args, **kwargs)

    @property
    def pendiente_recibir(self):
        return self.cantidad - self.cantidad_recibida


# ─────────────────────────────────────────────
#  RECEPCIÓN DE COMPRA
# ─────────────────────────────────────────────
class RecepcionCompra(models.Model):
    ESTADO_CHOICES = [
        ("pendiente",  "Pendiente de Revisión"),
        ("aprobada",   "Aprobada"),
        ("rechazada",  "Rechazada"),
    ]

    orden           = models.ForeignKey(
        OrdenCompra, on_delete=models.PROTECT, related_name="recepciones"
    )
    numero          = models.CharField(max_length=20, unique=True)
    fecha_recepcion = models.DateField()
    nro_factura     = models.CharField(max_length=50, blank=True, verbose_name="N° Factura Proveedor")
    estado          = models.CharField(max_length=10, choices=ESTADO_CHOICES, default="pendiente")
    observaciones   = models.TextField(blank=True)

    recibido_por    = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, related_name="recepciones_realizadas"
    )
    creado_en       = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name        = "Recepción de Compra"
        verbose_name_plural = "Recepciones de Compra"
        ordering            = ["-fecha_recepcion"]

    def __str__(self):
        return f"REC-{self.numero} | {self.orden}"

    @classmethod
    def generar_numero(cls):
        from django.utils import timezone
        year   = timezone.now().year
        ultimo = cls.objects.filter(numero__startswith=str(year)).order_by("-numero").first()
        if ultimo:
            try:
                seq = int(ultimo.numero.split("-")[-1]) + 1
            except (ValueError, IndexError):
                seq = 1
        else:
            seq = 1
        return f"{year}-{seq:04d}"


class DetalleRecepcion(models.Model):
    recepcion           = models.ForeignKey(
        RecepcionCompra, on_delete=models.CASCADE, related_name="detalles"
    )
    detalle_orden       = models.ForeignKey(
        DetalleOrdenCompra, on_delete=models.PROTECT, related_name="recepciones"
    )
    cantidad_recibida   = models.DecimalField(
        max_digits=12, decimal_places=2,
        validators=[MinValueValidator(Decimal("0.01"))]
    )
    cantidad_aceptada   = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal("0.00"))
    cantidad_rechazada  = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal("0.00"))
    observacion         = models.CharField(max_length=300, blank=True)

    class Meta:
        verbose_name        = "Detalle de Recepción"
        verbose_name_plural = "Detalles de Recepción"

    def __str__(self):
        return f"{self.recepcion} | {self.detalle_orden.producto}"
