# apps/compras/forms.py
from django import forms
from .models import (
    Proveedor, ContactoProveedor, CategoriaProveedor,
    ProductoCompra, CategoriaProductoCompra,
    OrdenCompra, DetalleOrdenCompra,
    RecepcionCompra, DetalleRecepcion,
)

CTR  = {"class": "form-control"}
SEL  = {"class": "form-select"}
NUM  = {"class": "form-control", "step": "0.01"}
DATE = {"class": "form-control", "type": "date"}
CHK  = {"class": "form-check-input"}
TXT  = {"class": "form-control", "rows": 3}


class CategoriaProveedorForm(forms.ModelForm):
    class Meta:
        model   = CategoriaProveedor
        fields  = ["nombre", "descripcion"]
        widgets = {"nombre": forms.TextInput(attrs=CTR), "descripcion": forms.Textarea(attrs=TXT)}


class ProveedorForm(forms.ModelForm):
    class Meta:
        model  = Proveedor
        fields = [
            "ruc", "razon_social", "nombre_comercial", "tipo", "categoria",
            "telefono", "telefono2", "email", "sitio_web",
            "direccion", "ciudad", "pais",
            "dias_credito", "descuento_pct", "cuenta_bancaria", "banco",
            "observaciones", "estado",
        ]
        widgets = {
            "ruc":             forms.TextInput(attrs=CTR),
            "razon_social":    forms.TextInput(attrs=CTR),
            "nombre_comercial":forms.TextInput(attrs=CTR),
            "tipo":            forms.Select(attrs=SEL),
            "categoria":       forms.Select(attrs=SEL),
            "telefono":        forms.TextInput(attrs=CTR),
            "telefono2":       forms.TextInput(attrs=CTR),
            "email":           forms.EmailInput(attrs=CTR),
            "sitio_web":       forms.URLInput(attrs=CTR),
            "direccion":       forms.Textarea(attrs={**TXT, "rows": 2}),
            "ciudad":          forms.TextInput(attrs=CTR),
            "pais":            forms.TextInput(attrs=CTR),
            "dias_credito":    forms.NumberInput(attrs=CTR),
            "descuento_pct":   forms.NumberInput(attrs=NUM),
            "cuenta_bancaria": forms.TextInput(attrs=CTR),
            "banco":           forms.TextInput(attrs=CTR),
            "observaciones":   forms.Textarea(attrs=TXT),
            "estado":          forms.Select(attrs=SEL),
        }


class ContactoProveedorForm(forms.ModelForm):
    class Meta:
        model   = ContactoProveedor
        fields  = ["nombre", "cargo", "telefono", "email", "principal"]
        widgets = {
            "nombre":    forms.TextInput(attrs=CTR),
            "cargo":     forms.TextInput(attrs=CTR),
            "telefono":  forms.TextInput(attrs=CTR),
            "email":     forms.EmailInput(attrs=CTR),
            "principal": forms.CheckboxInput(attrs=CHK),
        }


class CategoriaProductoCompraForm(forms.ModelForm):
    class Meta:
        model   = CategoriaProductoCompra
        fields  = ["nombre", "descripcion"]
        widgets = {"nombre": forms.TextInput(attrs=CTR), "descripcion": forms.Textarea(attrs=TXT)}


class ProductoCompraForm(forms.ModelForm):
    class Meta:
        model  = ProductoCompra
        fields = [
            "codigo", "nombre", "descripcion", "categoria",
            "unidad_medida", "precio_referencia", "stock_minimo", "activo",
        ]
        widgets = {
            "codigo":            forms.TextInput(attrs=CTR),
            "nombre":            forms.TextInput(attrs=CTR),
            "descripcion":       forms.Textarea(attrs=TXT),
            "categoria":         forms.Select(attrs=SEL),
            "unidad_medida":     forms.Select(attrs=SEL),
            "precio_referencia": forms.NumberInput(attrs={**NUM, "step": "0.0001"}),
            "stock_minimo":      forms.NumberInput(attrs=NUM),
            "activo":            forms.CheckboxInput(attrs=CHK),
        }


class OrdenCompraForm(forms.ModelForm):
    class Meta:
        model  = OrdenCompra
        fields = [
            "proveedor", "fecha_emision", "fecha_entrega",
            "dias_credito", "descuento_pct", "impuesto_pct",
            "notas", "terminos",
        ]
        widgets = {
            "proveedor":     forms.Select(attrs=SEL),
            "fecha_emision": forms.DateInput(attrs=DATE),
            "fecha_entrega": forms.DateInput(attrs=DATE),
            "dias_credito":  forms.NumberInput(attrs=CTR),
            "descuento_pct": forms.NumberInput(attrs=NUM),
            "impuesto_pct":  forms.NumberInput(attrs=NUM),
            "notas":         forms.Textarea(attrs=TXT),
            "terminos":      forms.Textarea(attrs=TXT),
        }


class DetalleOrdenCompraForm(forms.ModelForm):
    class Meta:
        model  = DetalleOrdenCompra
        fields = ["producto", "descripcion", "cantidad", "precio_unitario", "descuento_pct"]
        widgets = {
            "producto":       forms.Select(attrs=SEL),
            "descripcion":    forms.TextInput(attrs=CTR),
            "cantidad":       forms.NumberInput(attrs=NUM),
            "precio_unitario":forms.NumberInput(attrs={**NUM, "step": "0.0001"}),
            "descuento_pct":  forms.NumberInput(attrs=NUM),
        }


class RecepcionCompraForm(forms.ModelForm):
    class Meta:
        model  = RecepcionCompra
        fields = ["fecha_recepcion", "nro_factura", "observaciones"]
        widgets = {
            "fecha_recepcion": forms.DateInput(attrs=DATE),
            "nro_factura":     forms.TextInput(attrs=CTR),
            "observaciones":   forms.Textarea(attrs=TXT),
        }


class DetalleRecepcionForm(forms.ModelForm):
    class Meta:
        model  = DetalleRecepcion
        fields = ["detalle_orden", "cantidad_recibida", "cantidad_aceptada",
                  "cantidad_rechazada", "observacion"]
        widgets = {
            "detalle_orden":      forms.Select(attrs=SEL),
            "cantidad_recibida":  forms.NumberInput(attrs=NUM),
            "cantidad_aceptada":  forms.NumberInput(attrs=NUM),
            "cantidad_rechazada": forms.NumberInput(attrs=NUM),
            "observacion":        forms.TextInput(attrs=CTR),
        }
